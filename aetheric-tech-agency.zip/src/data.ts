import { ServiceTier, PortfolioItem, FAQItem } from "./types";

export const SERVICE_TIERS: ServiceTier[] = [
  {
    id: "ai-agents",
    title: "AI & Automation Agents",
    subtitle: "Tier 1: Autonomous Intelligent Systems",
    description: "Deploy production-grade autonomous intelligence. We build custom conversational AI, multi-agent n8n pipelines, and active voice interfaces designed to run 24/7.",
    features: [
      "n8n Production Workflow Pipelines",
      "Retell AI & Twilio Voice Integration",
      "Advanced LLM Fine-Tuning & Prompt Ops",
      "Auto-sync CRM & Ticketing Integrations",
      "Live Performance & Cost Telemetry Analytics"
    ],
    techStack: ["n8n", "Retell AI", "Gemini 3.5", "Pinecone", "NodeJS"],
    accentColor: "cyber-blue",
    iconName: "Cpu"
  },
  {
    id: "3d-websites",
    title: "3D Simple Websites",
    subtitle: "Tier 2: Immersive Webgl Showcases",
    description: "Stop building flat sites. We engineer light-speed 3D web experiences tailored with digital menu checkouts, custom configurable models, and fluid room booking systems.",
    features: [
      "Custom 3D WebGL / Spline Core Layouts",
      "Dynamic Product & Room Booking Configurators",
      "Interactive Digital Add-to-Cart Systems",
      "Fluid Device-Agnostic Responsive Styling",
      "Sub-second Load Optimization & Custom SEO"
    ],
    techStack: ["React Three Fiber", "Three.js", "Vite", "Tailwind CSS", "Motion"],
    accentColor: "cyber-purple",
    iconName: "Layers"
  },
  {
    id: "enterprise-fullstack",
    title: "Enterprise Full-Stack + App",
    subtitle: "Tier 3: Infinite Scale End-to-End Solutions",
    description: "Complete elite software architecture. Includes fully optimized consumer web interfaces, native mobile companions, embedded background agents, and dedicated analytical hubs.",
    features: [
      "High-Contrast Modern Client Dashboards",
      "Robust Express / Cloud SQL Scalable Backends",
      "Companion iOS & Android Native Layouts",
      "Integrated Autonomous Customer Care Hubs",
      "Full Sales, Subscriptions, SEO & Analytics suites"
    ],
    techStack: ["Express", "PostgreSQL", "React Native", "D3.js", "Redis"],
    accentColor: "cyber-pink",
    iconName: "Globe"
  }
];

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: "fast-food",
    title: "VaporBite: Future Food Hub",
    industry: "Fast Food & Restaurant Edition",
    description: "A gorgeous, interactive digital menu featuring fluid 3D item rotations, real-time nutrient graphs, and dynamic glassmorphic cart calculations.",
    badge: "Interactive 3D Menu",
    image: "🍔",
    accent: "cyber-blue",
    specs: [
      { label: "Rendering Core", value: "ThreeJS / WebGL" },
      { label: "Avg Load Time", value: "0.45 seconds" },
      { label: "Cart Conversion", value: "+38% improvement" }
    ]
  },
  {
    id: "digital-store",
    title: "AetherGear: Cybernetic Store",
    industry: "Digital E-Commerce Store",
    description: "High-end hardware showcase allowing clients to rotate modular custom accessories, preview dynamic neon skins, and trigger checkout seamlessly.",
    badge: "Custom product customizer",
    image: "🎧",
    accent: "cyber-purple",
    specs: [
      { label: "Skin Customizer", value: "Dynamic Canvas API" },
      { label: "Checkout Engine", value: "Stripe API Integration" },
      { label: "User Interaction", value: "3D Orbit Controls" }
    ]
  },
  {
    id: "luxury-hotel",
    title: "Horizon Zenith: Luxury Lodge",
    industry: "Luxury Hotel & Booking Engine",
    description: "A premium suite reservation dashboard featuring glassmorphic calendar schedulers, room inspections, and dynamic meal & service toggles.",
    badge: "Interactive Booking",
    image: "🏨",
    accent: "cyber-pink",
    specs: [
      { label: "Scheduler Core", value: "Custom React Grid" },
      { label: "Immersive View", value: "Panoramic Suite Inspection" },
      { label: "Upsell Utility", value: "Dining & Spa Toggles" }
    ]
  }
];

export const FAQ_ITEMS: FAQItem[] = [
  {
    id: "faq-1",
    question: "How long does a custom 3D Website or AI Agent build take?",
    answer: "A standard Tier 2 3D website or custom Tier 1 AI Agent is completed within 2 to 4 weeks. Full Enterprise Tier 3 projects generally span 6 to 8 weeks and include native mobile layout blueprints, specialized backend routers, and full n8n automation pipelines.",
    category: "General"
  },
  {
    id: "faq-2",
    question: "Do you configure custom n8n flows and AI voice models?",
    answer: "Yes, absolutely! Under our Tier 1 AI & Automation track, we specialize in configuring sophisticated n8n multi-agent chains, integrating Twilio voice systems with Retell AI, and connecting LLM routers to automate client support, outreach, and scheduling.",
    category: "AI"
  },
  {
    id: "faq-3",
    question: "Are the 3D models responsive on mobile phones?",
    answer: "Yes, our WebGL and Spline modules are custom-engineered with mobile-first viewport optimizations. Touch controls, orbit limits, and canvas scaling are debounced dynamically so that models look stunning and load instantly on any mobile device.",
    category: "3D Web"
  },
  {
    id: "faq-4",
    question: "Can we integrate this with existing CRM or ERP pipelines?",
    answer: "Of course! Our Enterprise Tier 3 systems are built with custom API proxies, webhook handlers, and database synchronization layers that tie directly into Salesforce, Hubspot, custom PostgreSQL systems, or Google Workspace configurations.",
    category: "General"
  }
];
