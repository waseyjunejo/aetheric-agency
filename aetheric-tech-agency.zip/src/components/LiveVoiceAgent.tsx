import React, { useState, useEffect, useRef } from "react";
import { Mic, Phone, Volume2, VolumeX, RefreshCw, Send, Play, Square, Sparkles, Server } from "lucide-react";
import { playClickSound, playHoverSound, playSuccessSound } from "../utils/audio";

interface ChatMessage {
  sender: "user" | "agent";
  text: string;
  timestamp: string;
}

const CONVERSATION_SCENARIOS = {
  booking: [
    { text: "Hello, I'd like to book the Celestial Starview Penthouse for 3 nights.", sender: "user" },
    { text: "Excellent choice! I've located open dates in July. Would you like me to add our custom AI Dining Sommelier service to this reservation?", sender: "agent" },
    { text: "Yes, please, and also add the Hypercar airport shuttle.", sender: "user" },
    { text: "Perfect. Your Obsidian-tier luxury package is fully locked in. A secure link with your invoice has been compiled and dispatched.", sender: "agent" }
  ],
  support: [
    { text: "The production database is throwing query latency spikes of 400ms.", sender: "user" },
    { text: "Understood. Accessing system nodes... I've isolated a rogue query thread and re-indexed the local database tables. Latency is now down to 3.8ms.", sender: "agent" },
    { text: "Wow, that was fast. Is the health check reporting fully green?", sender: "user" },
    { text: "Yes, diagnostic reports are 100% stable. Quantum memory limits and CPU thresholds are fully optimized.", sender: "agent" }
  ],
  quote: [
    { text: "How much would a custom AI Voice automation integration cost?", sender: "user" },
    { text: "Our custom voice agents running on high-throughput servers start at our Tier-1 scale. Let me compile a personalized architectural diagram for you.", sender: "agent" },
    { text: "Can you send the quote directly to my email?", sender: "user" },
    { text: "Absolutely. I've parsed your terminal session coordinates and will transmit the quote package immediately.", sender: "agent" }
  ]
};

export default function LiveVoiceAgent() {
  const [activeScenario, setActiveScenario] = useState<"booking" | "support" | "quote">("booking");
  const [isCalling, setIsCalling] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [transcript, setTranscript] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const [waves, setWaves] = useState<number[]>([10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]);
  
  const waveIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Animate speech visualizer waves when speaking
  useEffect(() => {
    if (isCalling && isTyping) {
      waveIntervalRef.current = setInterval(() => {
        setWaves(Array.from({ length: 18 }, () => Math.floor(Math.random() * 32) + 6));
      }, 70);
    } else if (isCalling && !isTyping) {
      // breathing passive state waves
      waveIntervalRef.current = setInterval(() => {
        setWaves(Array.from({ length: 18 }, (_, i) => Math.sin(Date.now() * 0.005 + i) * 8 + 12));
      }, 100);
    } else {
      setWaves(Array.from({ length: 18 }, () => 4));
      if (waveIntervalRef.current) clearInterval(waveIntervalRef.current);
    }

    return () => {
      if (waveIntervalRef.current) clearInterval(waveIntervalRef.current);
    };
  }, [isCalling, isTyping]);

  const speakText = (text: string) => {
    if (!ttsEnabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    
    // Stop any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    // Find a nice futuristic voice if possible, otherwise default
    const voices = window.speechSynthesis.getVoices();
    const synthVoice = voices.find(v => v.lang.includes("en-US") && v.name.toLowerCase().includes("google")) 
                    || voices.find(v => v.lang.includes("en")) 
                    || voices[0];
    
    if (synthVoice) {
      utterance.voice = synthVoice;
    }
    utterance.rate = 1.05; // Slightly faster modern pace
    utterance.pitch = 1.1; // Slightly higher synth pitch
    
    window.speechSynthesis.speak(utterance);
  };

  const handleStartCall = () => {
    playClickSound();
    setIsCalling(true);
    setTranscript([]);
    setCurrentStep(0);
    setIsTyping(true);

    setTimeout(() => {
      const initialMessage = "Hello, I am your Core Systems voice agent. How may I optimize your flows today?";
      setTranscript([
        {
          sender: "agent",
          text: initialMessage,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsTyping(false);
      speakText(initialMessage);
      playSuccessSound();
    }, 1000);
  };

  const handleStopCall = () => {
    playClickSound();
    setIsCalling(false);
    setIsTyping(false);
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  };

  const handleNextMessage = () => {
    if (!isCalling || isTyping) return;
    
    const scenario = CONVERSATION_SCENARIOS[activeScenario];
    if (currentStep >= scenario.length) {
      // Completed conversation
      const endingText = "Thank you for experiencing our AI Automation core systems. Our integration models are fully synchronized.";
      setIsTyping(true);
      speakText(endingText);
      setTimeout(() => {
        setTranscript(prev => [
          ...prev,
          {
            sender: "agent",
            text: endingText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        setIsTyping(false);
        playSuccessSound();
      }, 800);
      return;
    }

    const nextMsg = scenario[currentStep];
    
    // User message first
    playClickSound();
    setTranscript(prev => [
      ...prev,
      {
        sender: "user",
        text: nextMsg.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    
    setCurrentStep(prev => prev + 1);
    setIsTyping(true);

    // AI Voice response with slight delay
    const responseDelay = 1500;
    setTimeout(() => {
      const aiResponse = scenario[currentStep + 1];
      if (aiResponse) {
        setTranscript(prev => [
          ...prev,
          {
            sender: "agent",
            text: aiResponse.text,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        speakText(aiResponse.text);
        setCurrentStep(prev => prev + 1);
      }
      setIsTyping(false);
    }, responseDelay);
  };

  return (
    <div className="glass-panel rounded-2xl border border-white/10 p-6 md:p-8 relative overflow-hidden flex flex-col h-[520px]">
      
      {/* Glow ambient background elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-cyber-blue/10 blur-2xl pointer-events-none rounded-full" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-cyber-purple/10 blur-2xl pointer-events-none rounded-full" />

      {/* Header Title bar */}
      <div className="flex flex-wrap justify-between items-center pb-4 border-b border-white/5 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isCalling ? "bg-emerald-400" : "bg-cyber-blue/40"}`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${isCalling ? "bg-emerald-400" : "bg-cyber-blue"}`}></span>
            </span>
            <span className="text-xs font-mono text-gray-400">DEMO_TRACK: VOICE_AUTOMATION_AI</span>
          </div>
          <h4 className="text-lg font-display font-bold text-white mt-1">Live AI Voice Agent Preview</h4>
        </div>

        {/* TTS Toggle Switch */}
        <div className="flex items-center gap-2">
          <button
            onMouseEnter={playHoverSound}
            onClick={() => {
              playClickSound();
              setTtsEnabled(!ttsEnabled);
            }}
            className={`p-2 rounded-lg border transition-all text-xs flex items-center gap-1.5 ${
              ttsEnabled 
                ? "bg-cyber-blue/10 border-cyber-blue/30 text-cyber-blue" 
                : "bg-white/5 border-white/10 text-gray-400"
            }`}
            title={ttsEnabled ? "Text-to-Speech active" : "Text-to-Speech muted"}
          >
            {ttsEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="font-mono text-[10px] hidden sm:inline">VOICE_AUDIO</span>
          </button>
        </div>
      </div>

      {/* Conversation/Scenario selectors */}
      <div className="flex gap-2 my-4">
        <button
          onMouseEnter={playHoverSound}
          onClick={() => {
            playClickSound();
            setActiveScenario("booking");
            if (isCalling) handleStopCall();
          }}
          className={`flex-1 py-1.5 px-3 rounded-lg border text-xs font-mono transition-all ${
            activeScenario === "booking"
              ? "bg-cyber-purple/10 border-cyber-purple/40 text-white"
              : "bg-white/5 border-white/5 text-gray-400 hover:bg-white/10"
          }`}
        >
          Concierge Booking
        </button>
        <button
          onMouseEnter={playHoverSound}
          onClick={() => {
            playClickSound();
            setActiveScenario("support");
            if (isCalling) handleStopCall();
          }}
          className={`flex-1 py-1.5 px-3 rounded-lg border text-xs font-mono transition-all ${
            activeScenario === "support"
              ? "bg-cyber-purple/10 border-cyber-purple/40 text-white"
              : "bg-white/5 border-white/5 text-gray-400 hover:bg-white/10"
          }`}
        >
          Tech DB Support
        </button>
        <button
          onMouseEnter={playHoverSound}
          onClick={() => {
            playClickSound();
            setActiveScenario("quote");
            if (isCalling) handleStopCall();
          }}
          className={`flex-1 py-1.5 px-3 rounded-lg border text-xs font-mono transition-all ${
            activeScenario === "quote"
              ? "bg-cyber-purple/10 border-cyber-purple/40 text-white"
              : "bg-white/5 border-white/5 text-gray-400 hover:bg-white/10"
          }`}
        >
          Automated Quote
        </button>
      </div>

      {/* Main chat window */}
      <div className="flex-1 overflow-y-auto bg-black/40 border border-white/5 rounded-xl p-4 my-2 flex flex-col gap-3 min-h-0 scrollbar-thin">
        {!isCalling ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
            <div className="w-14 h-14 rounded-full bg-cyber-blue/10 flex items-center justify-center text-cyber-blue mb-4 border border-cyber-blue/20 animate-pulse">
              <Mic className="w-6 h-6" />
            </div>
            <p className="font-display font-medium text-white text-sm">Initialize AI Agent Voice Channel</p>
            <p className="text-xs text-gray-500 mt-2 max-w-xs">
              Demonstrate ultra-low latency voice agents utilizing Retell AI & custom natural text-to-speech outputs.
            </p>
            <button
              onMouseEnter={playHoverSound}
              onClick={handleStartCall}
              className="mt-5 px-5 py-2.5 bg-cyber-blue text-black font-display font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg shadow-cyber-blue/20 transition-all hover:bg-cyber-blue/90 flex items-center gap-2"
            >
              <Phone className="w-3.5 h-3.5 fill-current" /> Establish Connection
            </button>
          </div>
        ) : (
          <>
            {transcript.map((msg, i) => (
              <div
                key={i}
                className={`flex flex-col max-w-[85%] ${msg.sender === "user" ? "self-end items-end" : "self-start items-start"}`}
              >
                <div className={`text-[9px] font-mono text-gray-500 mb-1`}>
                  {msg.sender === "user" ? "USER" : "AGENT_COGNITIVE"} • {msg.timestamp}
                </div>
                <div
                  className={`p-3 rounded-xl text-xs leading-relaxed ${
                    msg.sender === "user"
                      ? "bg-cyber-purple/10 border border-cyber-purple/30 text-white rounded-tr-none"
                      : "bg-white/[0.03] border border-white/10 text-gray-200 rounded-tl-none shadow-md shadow-black/20"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="self-start flex items-center gap-1.5 bg-white/[0.02] border border-white/5 p-3 rounded-xl rounded-tl-none">
                <span className="w-1.5 h-1.5 bg-cyber-blue rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></span>
                <span className="w-1.5 h-1.5 bg-cyber-blue rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></span>
                <span className="w-1.5 h-1.5 bg-cyber-blue rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></span>
              </div>
            )}
          </>
        )}
      </div>

      {/* Voice visualizer & Call controls */}
      <div className="pt-4 border-t border-white/5 flex flex-col sm:flex-row items-center gap-4">
        
        {/* Animated wave lines */}
        <div className="flex-1 flex items-center justify-center gap-[3px] h-12 px-4 bg-black/20 border border-white/5 rounded-lg w-full">
          {waves.map((h, i) => (
            <div
              key={i}
              style={{ height: `${h}px` }}
              className={`w-[3px] rounded-full transition-all duration-75 ${
                isCalling 
                  ? isTyping 
                    ? "bg-gradient-to-t from-cyber-blue to-cyber-purple shadow-[0_0_10px_rgba(0,210,255,0.4)]"
                    : "bg-cyber-blue/40"
                  : "bg-white/10"
              }`}
            />
          ))}
        </div>

        {/* Buttons */}
        {isCalling && (
          <div className="flex gap-2 w-full sm:w-auto">
            <button
              onMouseEnter={playHoverSound}
              onClick={handleNextMessage}
              disabled={isTyping}
              className={`flex-1 sm:flex-initial px-4 py-3 rounded-lg font-display text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                isTyping 
                  ? "bg-white/5 border border-white/5 text-gray-500 cursor-not-allowed"
                  : "bg-white/10 border border-white/10 hover:bg-white/15 text-white"
              }`}
            >
              <Send className="w-3.5 h-3.5" /> Speak Next
            </button>
            <button
              onMouseEnter={playHoverSound}
              onClick={handleStopCall}
              className="px-4 py-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500/20 rounded-lg font-display text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5"
            >
              <Square className="w-3.5 h-3.5" /> Terminate
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
