import React, { useState } from "react";
import { ShoppingCart, Compass, Plus, Minus, Check, Sparkles, MapPin, Calendar, Flame, Coffee, Activity, ArrowRight, CheckCircle2, RefreshCw } from "lucide-react";
import { playClickSound, playSuccessSound } from "../utils/audio";

type DemoType = "restaurant" | "store" | "hotel";

interface MenuItem {
  id: string;
  name: string;
  emoji: string;
  calories: number;
  price: number;
  accent: string;
}

interface ProductItem {
  id: string;
  name: string;
  basePrice: number;
  emoji: string;
}

export default function InteractiveDemos() {
  const [activeTab, setActiveTab] = useState<DemoType>("restaurant");

  // --- FAST FOOD / RESTAURANT STATES ---
  const fastFoodMenu: MenuItem[] = [
    { id: "burger", name: "Cyberpunk Glitch Burger", emoji: "🍔", calories: 650, price: 14.99, accent: "text-cyber-blue border-cyber-blue/30" },
    { id: "fries", name: "Plasma Fries (Glow)", emoji: "🍟", calories: 320, price: 5.99, accent: "text-cyber-purple border-cyber-purple/30" },
    { id: "shake", name: "Quantum Antimatter Cola", emoji: "🥤", calories: 150, price: 4.49, accent: "text-cyber-pink border-cyber-pink/30" }
  ];

  const [restaurantCart, setRestaurantCart] = useState<{ [key: string]: number }>({ burger: 1 });

  // Checkout form states
  const [checkoutName, setCheckoutName] = useState("");
  const [checkoutEmail, setCheckoutEmail] = useState("");
  const [checkoutPhone, setCheckoutPhone] = useState("");
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);
  const [checkoutLoading, setCheckoutLoading] = useState(false);

  const handleCheckoutSubmit = async () => {
    if (!checkoutName || !checkoutEmail || !checkoutPhone) {
      alert("Please supply all checkout coordinates to dispatch your order signal!");
      return;
    }
    setCheckoutLoading(true);
    playClickSound();
    try {
      const orderItems = Object.entries(restaurantCart).map(([id, qty]) => {
        const item = fastFoodMenu.find(m => m.id === id);
        return {
          id,
          name: item?.name || id,
          qty,
          price: item?.price || 0,
          calories: item?.calories || 0
        };
      });

      const totalAmount = getCartTotal() + 1.20;

      const response = await fetch("/api/restaurant/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: checkoutName,
          clientEmail: checkoutEmail,
          clientPhone: checkoutPhone,
          orderItems,
          totalAmount
        })
      });

      const data = await response.json();
      if (data.success) {
        setCheckoutSuccess(true);
        playSuccessSound();
      }
    } catch (err) {
      console.error("Restaurant order checkout failed:", err);
      alert("An issue occurred sending your order signal. Try again shortly.");
    } finally {
      setCheckoutLoading(false);
    }
  };

  const updateCart = (id: string, delta: number) => {
    setRestaurantCart(prev => {
      const current = prev[id] || 0;
      const next = current + delta;
      const updated = { ...prev };
      if (next <= 0) {
        delete updated[id];
      } else {
        updated[id] = next;
      }
      return updated;
    });
  };

  const getCartTotal = () => {
    return (Object.entries(restaurantCart) as [string, number][]).reduce((total: number, [id, qty]) => {
      const item = fastFoodMenu.find(m => m.id === id);
      return total + (item ? item.price * qty : 0);
    }, 0);
  };

  // --- E-COMMERCE / DIGITAL STORE STATES ---
  const storeProduct: ProductItem = {
    id: "headset",
    name: "Aetheric H-9 Cybernetic Headset",
    basePrice: 249.99,
    emoji: "🎧"
  };

  const [selectedColor, setSelectedColor] = useState<"blue" | "purple" | "pink">("blue");
  const [selectedAccessories, setSelectedAccessories] = useState<string[]>(["anc"]);

  const accessoriesList = [
    { id: "anc", name: "Embedded Hybrid ANC (+60dB)", price: 49.99 },
    { id: "ai-core", name: "Neural Gemini Voice Core v3.5", price: 79.99 },
    { id: "carbon", name: "Ultra-Light Carbon-Fiber Frame", price: 34.99 }
  ];

  const toggleAccessory = (id: string) => {
    setSelectedAccessories(prev =>
      prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]
    );
  };

  const getProductTotal = () => {
    let total = storeProduct.basePrice;
    selectedAccessories.forEach(accId => {
      const acc = accessoriesList.find(a => a.id === accId);
      if (acc) total += acc.price;
    });
    return total;
  };

  // --- LUXURY HOTEL STATES ---
  const suites = [
    { id: "celestial", name: "Celestial Starview Penthouse", rate: 599, emoji: "🌌", specs: "1,200 sq. ft. • Holographic Dome" },
    { id: "obsidian", name: "Obsidian Infinity Suite", rate: 389, emoji: "💎", specs: "850 sq. ft. • Quantum Spa Access" }
  ];

  const [selectedSuite, setSelectedSuite] = useState("celestial");
  const [bookingDays, setBookingDays] = useState(3);
  const [addOns, setAddOns] = useState<string[]>(["sommelier"]);

  const hotelAddOns = [
    { id: "shuttle", name: "Hypercar Airport Shuttle (Tesla Roadster)", price: 150 },
    { id: "sommelier", name: "AI Dining Sommelier Curated Meal Menu", price: 85 },
    { id: "massage", name: "Neural Sleep Bio-Tuning Therapy Session", price: 120 }
  ];

  const toggleAddOn = (id: string) => {
    setAddOns(prev =>
      prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]
    );
  };

  const getHotelTotal = () => {
    const suite = suites.find(s => s.id === selectedSuite);
    const base = suite ? suite.rate * bookingDays : 0;
    const extra = addOns.reduce((total: number, addOnId: string) => {
      const item = hotelAddOns.find(a => a.id === addOnId);
      return total + (item ? item.price : 0);
    }, 0);
    return base + extra;
  };

  return (
    <div className="w-full relative mt-12 perspective-1000">
      {/* Sub Tab Navigation */}
      <div className="flex flex-wrap justify-center gap-3 mb-8">
        <button
          onClick={() => setActiveTab("restaurant")}
          className={`px-5 py-2.5 rounded-full text-sm font-display font-medium tracking-wide transition-all border ${
            activeTab === "restaurant"
              ? "bg-gradient-to-r from-cyber-blue/20 to-cyber-purple/20 border-cyber-blue text-cyber-blue glow-border-blue"
              : "bg-dark-surface/60 border-white/5 text-gray-400 hover:border-white/10 hover:text-white"
          }`}
        >
          🍔 Fast Food Menu
        </button>
        <button
          onClick={() => setActiveTab("store")}
          className={`px-5 py-2.5 rounded-full text-sm font-display font-medium tracking-wide transition-all border ${
            activeTab === "store"
              ? "bg-gradient-to-r from-cyber-purple/20 to-cyber-pink/20 border-cyber-purple text-cyber-purple glow-border-purple"
              : "bg-dark-surface/60 border-white/5 text-gray-400 hover:border-white/10 hover:text-white"
          }`}
        >
          🎧 Cybernetic Store
        </button>
        <button
          onClick={() => setActiveTab("hotel")}
          className={`px-5 py-2.5 rounded-full text-sm font-display font-medium tracking-wide transition-all border ${
            activeTab === "hotel"
              ? "bg-gradient-to-r from-cyber-pink/20 to-cyber-blue/20 border-cyber-pink text-cyber-pink"
              : "bg-dark-surface/60 border-white/5 text-gray-400 hover:border-white/10 hover:text-white"
          }`}
        >
          🏨 Luxury Hotel Reservation
        </button>
      </div>

      {/* Demo Container Frame */}
      <div className="glass-panel rounded-2xl overflow-hidden border border-white/10 relative p-6 md:p-8">
        {/* Glow overlay relative to active tab */}
        <div
          className={`absolute -top-24 -left-24 w-48 h-48 rounded-full blur-[80px] opacity-30 transition-all ${
            activeTab === "restaurant"
              ? "bg-cyber-blue"
              : activeTab === "store"
              ? "bg-cyber-purple"
              : "bg-cyber-pink"
          }`}
        />

        {/* --- RESTAURANT MENU DEMO --- */}
        {activeTab === "restaurant" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7">
              <div className="flex items-center gap-2 mb-4">
                <span className="px-2 py-0.5 bg-cyber-blue/10 border border-cyber-blue/30 text-cyber-blue text-xs font-mono rounded">
                  Tier 2 Interactive Showcase
                </span>
                <span className="text-xs text-gray-400 font-mono">Fast Food Template</span>
              </div>
              <h4 className="text-2xl font-display font-bold text-white mb-2">
                Fluid Digital Menu & Automated Checkout
              </h4>
              <p className="text-sm text-gray-400 mb-6">
                Demonstrates smooth 3D hovering panels, auto-calculating calorie counters, and rapid digital add-to-cart pipelines designed to trigger kitchen alerts immediately.
              </p>

              {/* Menu items list */}
              <div className="space-y-3">
                {fastFoodMenu.map(item => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <div className="text-3xl p-2 rounded-lg bg-white/[0.03] select-none animate-bounce" style={{ animationDuration: item.id === "burger" ? "3s" : item.id === "fries" ? "2.5s" : "4s" }}>
                        {item.emoji}
                      </div>
                      <div>
                        <h5 className="font-display font-semibold text-white text-base">{item.name}</h5>
                        <div className="flex items-center gap-3 mt-1 text-xs text-gray-400 font-mono">
                          <span className="flex items-center gap-1">
                            <Flame className="w-3.5 h-3.5 text-amber-500" /> {item.calories} kCal
                          </span>
                          <span>•</span>
                          <span className="text-cyber-blue">${item.price}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => updateCart(item.id, 1)}
                      className="flex items-center justify-center p-2 rounded-lg bg-cyber-blue/10 hover:bg-cyber-blue text-cyber-blue hover:text-black transition-all border border-cyber-blue/30 hover:border-transparent"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Shopping Cart Drawer */}
            <div className="lg:col-span-5 bg-dark-surface/80 border border-white/5 rounded-xl p-6 relative">
              <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
                <h5 className="font-display font-bold text-white flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-cyber-blue" />
                  Your CyberTray
                </h5>
                <span className="text-xs font-mono px-2 py-0.5 bg-white/10 rounded text-gray-300">
                  {Object.values(restaurantCart).reduce((a: number, b: number) => a + b, 0)} items
                </span>
              </div>

              {checkoutSuccess ? (
                <div className="text-center py-6 space-y-4 font-mono text-xs">
                  <CheckCircle2 className="w-12 h-12 text-cyber-blue mx-auto animate-bounce" />
                  <h5 className="font-display font-bold text-white text-base">ORDER DISPATCHED</h5>
                  <p className="text-xs text-gray-400">
                    Your checkout specs have been processed! Real-time notifications have been successfully routed to:
                  </p>
                  <div className="bg-black/60 border border-white/5 p-3 rounded-lg text-left text-[11px] text-cyber-blue space-y-1">
                    <div>• Email Recipient: <span className="text-white font-bold">wjunejo@gmail.com</span></div>
                    <div>• WhatsApp Alert: <span className="text-white font-bold">0331249213</span></div>
                  </div>
                  <p className="text-[10px] text-gray-500 leading-normal">
                    The Aetheric team has received this transaction. We will reach out directly to coordinate final delivery!
                  </p>
                  <button
                    onClick={() => {
                      playClickSound();
                      setCheckoutSuccess(false);
                      setRestaurantCart({});
                      setIsCheckingOut(false);
                      setCheckoutName("");
                      setCheckoutEmail("");
                      setCheckoutPhone("");
                    }}
                    className="w-full mt-2 py-2 bg-cyber-blue/10 border border-cyber-blue/30 text-cyber-blue text-[10px] uppercase font-bold rounded-lg hover:bg-cyber-blue hover:text-black transition-all"
                  >
                    Reset Order Demo
                  </button>
                </div>
              ) : isCheckingOut ? (
                <div className="space-y-4 font-mono text-xs">
                  <h5 className="font-display font-bold text-white text-xs uppercase tracking-wider text-cyber-purple">Quantum Checkout Fields</h5>
                  <p className="text-[10px] text-gray-400 leading-relaxed">
                    Please supply your contact coordinates to route notifications and trigger simulated kitchen webhooks:
                  </p>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-[9px] text-gray-500 uppercase mb-1">Full Name</label>
                      <input
                        type="text"
                        value={checkoutName}
                        onChange={(e) => setCheckoutName(e.target.value)}
                        placeholder="e.g. John Doe"
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyber-purple font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] text-gray-500 uppercase mb-1">Email Coordinates</label>
                      <input
                        type="email"
                        value={checkoutEmail}
                        onChange={(e) => setCheckoutEmail(e.target.value)}
                        placeholder="e.g. john@example.com"
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyber-purple font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] text-gray-500 uppercase mb-1">WhatsApp / Phone</label>
                      <input
                        type="text"
                        value={checkoutPhone}
                        onChange={(e) => setCheckoutPhone(e.target.value)}
                        placeholder="e.g. 0331249213"
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyber-purple font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => {
                        playClickSound();
                        setIsCheckingOut(false);
                      }}
                      className="flex-1 py-2 bg-white/5 border border-white/10 text-gray-400 text-[10px] uppercase font-bold rounded-lg hover:text-white transition-all"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleCheckoutSubmit}
                      disabled={checkoutLoading}
                      className="flex-1 py-2 bg-cyber-blue text-black font-display font-bold text-[10px] uppercase rounded-lg hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-cyber-blue/20 flex items-center justify-center gap-1.5"
                    >
                      {checkoutLoading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> DISPATCHING...
                        </>
                      ) : (
                        "Transmit Order"
                      )}
                    </button>
                  </div>
                </div>
              ) : Object.keys(restaurantCart).length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <p className="text-sm">Your tray is empty.</p>
                  <p className="text-xs mt-1 font-mono">Add items from the neon menu on the left!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {Object.entries(restaurantCart).map(([id, qty]) => {
                    const item = fastFoodMenu.find(m => m.id === id);
                    if (!item) return null;
                    return (
                      <div key={id} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{item.emoji}</span>
                          <div>
                            <p className="font-semibold text-white">{item.name}</p>
                            <p className="text-xs text-cyber-blue font-mono">${item.price} each</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              playClickSound();
                              updateCart(id, -1);
                            }}
                            className="p-1 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="font-mono text-white text-xs px-1.5">{qty}</span>
                          <button
                            onClick={() => {
                              playClickSound();
                              updateCart(id, 1);
                            }}
                            className="p-1 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}

                  <div className="pt-4 border-t border-white/10 space-y-2">
                    <div className="flex justify-between text-xs text-gray-400 font-mono">
                      <span>Quantum Tax (Glow Charge)</span>
                      <span className="font-mono">$1.20</span>
                    </div>
                    <div className="flex justify-between text-sm font-semibold font-mono">
                      <span className="text-white">Estimated Subtotal</span>
                      <span className="text-cyber-blue font-mono font-bold">
                        ${(getCartTotal() + 1.20).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      playClickSound();
                      setIsCheckingOut(true);
                    }}
                    className="w-full mt-4 py-2.5 rounded-lg bg-cyber-blue text-black font-display font-bold text-xs uppercase tracking-wider hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-cyber-blue/20"
                  >
                    Transmit Order Signal
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* --- DIGITAL STORE DEMO --- */}
        {activeTab === "store" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Visualizer Area */}
            <div className="lg:col-span-6 flex flex-col items-center justify-center bg-dark-surface/50 border border-white/5 rounded-xl p-8 min-h-[300px] relative overflow-hidden">
              {/* Spinning technical ring acting as our premium 3D design core */}
              <div className="absolute w-56 h-56 rounded-full border border-dashed border-white/5 animate-tech-spin" />
              <div
                className={`absolute w-44 h-44 rounded-full border border-double blur-[2px] transition-all duration-700 ${
                  selectedColor === "blue"
                    ? "border-cyber-blue shadow-[0_0_30px_rgba(0,240,255,0.2)]"
                    : selectedColor === "purple"
                    ? "border-cyber-purple shadow-[0_0_30px_rgba(189,0,255,0.2)]"
                    : "border-cyber-pink shadow-[0_0_30px_rgba(255,0,122,0.2)]"
                }`}
              />

              {/* Product 3D Hovering Emoji Placeholder */}
              <div className="relative text-7xl select-none filter drop-shadow-[0_10px_15px_rgba(255,255,255,0.15)] animate-bounce duration-1000">
                {storeProduct.emoji}
                {/* Embedded Glow Spot */}
                <div
                  className={`absolute -bottom-2 left-1/2 -translate-x-1/2 w-10 h-2 rounded-full blur-md transition-all duration-700 ${
                    selectedColor === "blue"
                      ? "bg-cyber-blue"
                      : selectedColor === "purple"
                      ? "bg-cyber-purple"
                      : "bg-cyber-pink"
                  }`}
                />
              </div>

              {/* Live Status Telemetry lines */}
              <div className="mt-8 text-center space-y-1 relative z-10">
                <div className="text-xs font-mono text-gray-500">
                  RENDER CORE STATUS: <span className="text-green-400">ONLINE</span>
                </div>
                <div className="text-xs font-mono text-gray-400 flex items-center gap-2 justify-center">
                  <span>SKIN ENVELOPE:</span>
                  <span
                    className={`uppercase font-bold ${
                      selectedColor === "blue"
                        ? "text-cyber-blue"
                        : selectedColor === "purple"
                        ? "text-cyber-purple"
                        : "text-cyber-pink"
                    }`}
                  >
                    {selectedColor}-Glow
                  </span>
                </div>
              </div>
            </div>

            {/* Customization Options */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <span className="px-2 py-0.5 bg-cyber-purple/10 border border-cyber-purple/30 text-cyber-purple text-xs font-mono rounded">
                  E-Commerce 3D Store Template
                </span>
                <h4 className="text-2xl font-display font-bold text-white mt-3 mb-2">
                  Interactive Modular Customizer
                </h4>
                <p className="text-sm text-gray-400">
                  Live color-tuning and add-on triggers. Perfect for e-commerce brands showcasing high-end devices, watches, shoes, or customizable merchandise.
                </p>
              </div>

              {/* Color Tuning */}
              <div>
                <h5 className="text-xs font-mono uppercase text-gray-400 tracking-wider mb-2">
                  Tune Metallic Skin Accent
                </h5>
                <div className="flex gap-3">
                  <button
                    onClick={() => setSelectedColor("blue")}
                    className={`w-8 h-8 rounded-full bg-cyber-blue border-2 transition-all ${
                      selectedColor === "blue" ? "border-white scale-110 shadow-lg shadow-cyber-blue/30" : "border-transparent"
                    }`}
                  />
                  <button
                    onClick={() => setSelectedColor("purple")}
                    className={`w-8 h-8 rounded-full bg-cyber-purple border-2 transition-all ${
                      selectedColor === "purple" ? "border-white scale-110 shadow-lg shadow-cyber-purple/30" : "border-transparent"
                    }`}
                  />
                  <button
                    onClick={() => setSelectedColor("pink")}
                    className={`w-8 h-8 rounded-full bg-cyber-pink border-2 transition-all ${
                      selectedColor === "pink" ? "border-white scale-110 shadow-lg shadow-cyber-pink/30" : "border-transparent"
                    }`}
                  />
                </div>
              </div>

              {/* Modular Accessories */}
              <div>
                <h5 className="text-xs font-mono uppercase text-gray-400 tracking-wider mb-2">
                  Select Accessory Upgrades
                </h5>
                <div className="space-y-2">
                  {accessoriesList.map(acc => {
                    const isSelected = selectedAccessories.includes(acc.id);
                    return (
                      <button
                        key={acc.id}
                        onClick={() => toggleAccessory(acc.id)}
                        className={`w-full flex items-center justify-between p-3 rounded-lg border text-left text-sm transition-all ${
                          isSelected
                            ? "bg-cyber-purple/10 border-cyber-purple text-white"
                            : "bg-white/[0.01] border-white/5 text-gray-400 hover:border-white/10"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`w-4.5 h-4.5 rounded flex items-center justify-center border ${
                            isSelected ? "border-cyber-purple bg-cyber-purple text-black" : "border-white/20"
                          }`}>
                            {isSelected && <Check className="w-3.5 h-3.5 stroke-[3px]" />}
                          </div>
                          <span>{acc.name}</span>
                        </div>
                        <span className="font-mono text-xs text-cyber-purple">+${acc.price}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Total Summary */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-xs text-gray-400 block">Configured Price</span>
                  <span className="text-2xl font-display font-bold text-white font-mono">
                    ${getProductTotal().toFixed(2)}
                  </span>
                </div>
                <button
                  onClick={() => alert("Pre-order signal sent! This interactive customizer integrates with any e-commerce basket state.")}
                  className="px-6 py-2.5 rounded-lg bg-cyber-purple hover:bg-cyber-purple/80 text-white text-xs font-display font-bold uppercase tracking-wider transition-all"
                >
                  Configure and Order
                </button>
              </div>
            </div>
          </div>
        )}

        {/* --- LUXURY HOTEL DEMO --- */}
        {activeTab === "hotel" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 space-y-6">
              <div>
                <span className="px-2 py-0.5 bg-cyber-pink/10 border border-cyber-pink/30 text-cyber-pink text-xs font-mono rounded">
                  Luxury Hotel & Booking Engine Template
                </span>
                <h4 className="text-2xl font-display font-bold text-white mt-3 mb-2">
                  Immersive Reservation & Experience Schedulers
                </h4>
                <p className="text-sm text-gray-400">
                  Our hotels layouts provide prospective guests with custom room selections, check-in schedules, and dynamic experience upgrades, driving booking values to record heights.
                </p>
              </div>

              {/* Room Suite Selection */}
              <div>
                <h5 className="text-xs font-mono uppercase text-gray-400 tracking-wider mb-2">
                  Select Luxury Suite
                </h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {suites.map(suite => {
                    const isSelected = selectedSuite === suite.id;
                    return (
                      <button
                        key={suite.id}
                        onClick={() => setSelectedSuite(suite.id)}
                        className={`p-4 rounded-xl text-left border transition-all ${
                          isSelected
                            ? "bg-cyber-pink/10 border-cyber-pink text-white"
                            : "bg-white/[0.01] border-white/5 text-gray-400 hover:border-white/10"
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-2xl">{suite.emoji}</span>
                          <span className="font-display font-bold text-sm text-white">{suite.name}</span>
                        </div>
                        <p className="text-xs text-gray-400 mb-2">{suite.specs}</p>
                        <span className="text-xs font-mono text-cyber-pink">${suite.rate} / Night</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Stay Duration */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <h5 className="text-xs font-mono uppercase text-gray-400 tracking-wider">
                    Stay Duration (Nights)
                  </h5>
                  <span className="text-sm font-mono text-white font-bold">{bookingDays} Nights</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="14"
                  value={bookingDays}
                  onChange={(e) => setBookingDays(parseInt(e.target.value))}
                  className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-cyber-pink"
                />
                <div className="flex justify-between text-[10px] text-gray-500 font-mono mt-1">
                  <span>1 Night</span>
                  <span>7 Nights</span>
                  <span>14 Nights</span>
                </div>
              </div>
            </div>

            {/* Price Calculator Tray */}
            <div className="lg:col-span-5 bg-dark-surface/80 border border-white/5 rounded-xl p-6 relative">
              <h5 className="font-display font-bold text-white mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-cyber-pink" />
                Live Quote Summary
              </h5>

              <div className="space-y-4">
                {/* Suite details */}
                <div className="p-3 bg-white/[0.02] rounded-lg border border-white/5 flex items-center gap-3">
                  <span className="text-3xl">
                    {suites.find(s => s.id === selectedSuite)?.emoji}
                  </span>
                  <div>
                    <span className="text-xs text-gray-400">Selected Option</span>
                    <p className="text-sm font-bold text-white">
                      {suites.find(s => s.id === selectedSuite)?.name}
                    </p>
                  </div>
                </div>

                {/* Service Toggles */}
                <div>
                  <span className="text-xs font-mono text-gray-400 block mb-2 uppercase">Experience Upplays</span>
                  <div className="space-y-2">
                    {hotelAddOns.map(addon => {
                      const active = addOns.includes(addon.id);
                      return (
                        <button
                          key={addon.id}
                          onClick={() => toggleAddOn(addon.id)}
                          className={`w-full flex items-center justify-between p-2.5 rounded text-left text-xs transition-all ${
                            active
                              ? "bg-cyber-pink/5 border border-cyber-pink/40 text-white"
                              : "border border-white/5 bg-white/[0.005] text-gray-400 hover:border-white/10"
                          }`}
                        >
                          <span>{addon.name}</span>
                          <span className="font-mono text-cyber-pink">+${addon.price}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Math breakdown */}
                <div className="pt-3 border-t border-white/10 space-y-1.5 text-xs">
                  <div className="flex justify-between text-gray-400">
                    <span>Room Cost ({bookingDays} nights)</span>
                    <span className="font-mono">${(suites.find(s => s.id === selectedSuite)?.rate || 0) * bookingDays}</span>
                  </div>
                  <div className="flex justify-between text-gray-400">
                    <span>Selected Services Upgrades</span>
                    <span className="font-mono">
                      ${addOns.reduce((a: number, b: string) => a + (hotelAddOns.find(x => x.id === b)?.price || 0), 0)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-bold pt-2 border-t border-white/5">
                    <span className="text-white">Estimated Quote Total</span>
                    <span className="text-cyber-pink font-mono font-bold text-base">
                      ${getHotelTotal().toFixed(2)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => alert("Booking request submitted! In full agency setups, this starts an automated guest booking webhook to sync reservations with the resort's PMS system.")}
                  className="w-full mt-2 py-2.5 rounded-lg bg-cyber-pink text-white font-display font-bold text-xs uppercase tracking-wider hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-cyber-pink/20"
                >
                  Send Booking Inquiry
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
