import React, { useEffect, useRef, useState } from "react";

interface ScrollRevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number; // delay in milliseconds
  duration?: number; // duration in milliseconds
  threshold?: number;
  key?: string | number;
  variant?: "slide-up" | "slide-down" | "slide-left" | "slide-right" | "scale" | "fade";
  distance?: number; // translation distance in pixels
}

export function ScrollReveal({
  children,
  className = "",
  delay = 0,
  duration = 800,
  threshold = 0.05,
  variant = "slide-up",
  distance = 30,
}: ScrollRevealProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          if (ref.current) {
            observer.unobserve(ref.current);
          }
        }
      },
      {
        threshold,
        rootMargin: "0px 0px -50px 0px" // triggers slightly before entering viewport fully
      }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [threshold]);

  // Determine starting transforms
  let transform = "none";
  if (!isVisible) {
    switch (variant) {
      case "slide-up":
        transform = `translateY(${distance}px)`;
        break;
      case "slide-down":
        transform = `translateY(${-distance}px)`;
        break;
      case "slide-left":
        transform = `translateX(${distance}px)`;
        break;
      case "slide-right":
        transform = `translateX(${-distance}px)`;
        break;
      case "scale":
        transform = "scale(0.96)";
        break;
      case "fade":
      default:
        transform = "none";
        break;
    }
  } else {
    transform = variant === "scale" ? "scale(1)" : "translate(0, 0)";
  }

  const style: React.CSSProperties = {
    opacity: isVisible ? 1 : 0,
    transform,
    filter: isVisible ? "blur(0px)" : "blur(4px)",
    transitionProperty: "opacity, transform, filter",
    transitionDuration: `${duration}ms`,
    transitionDelay: `${delay}ms`,
    transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)", // Custom premium cubic-bezier easeOutExpo curve
  };

  return (
    <div
      ref={ref}
      style={style}
      className={className}
    >
      {children}
    </div>
  );
}
