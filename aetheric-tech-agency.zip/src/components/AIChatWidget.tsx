import React, { useState, useEffect, useRef } from "react";
import { 
  MessageSquare, X, Send, Mic, MicOff, Volume2, VolumeX, 
  Sparkles, ShieldCheck, RefreshCw, CheckCircle2, User, Bot, Clock
} from "lucide-react";
import { playClickSound, playHoverSound, playSuccessSound } from "../utils/audio";

interface Message {
  sender: "user" | "agent";
  text: string;
  timestamp: string;
}

export default function AIChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"chat" | "voice">("chat");
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: "agent",
      text: "Hello, welcome to our website! I am your sales assistant at Aetheric Studios. How can I assist you with our 3D Web & AI Automation services today?",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  const [inputVal, setInputVal] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [languageDetected, setLanguageDetected] = useState("AUTO-DETECT");
  
  // Voice Synthesis & Recognition states
  const [isListening, setIsListening] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [recognition, setRecognition] = useState<any>(null);

  // Lead capture states parsed from AI responses
  const [leadName, setLeadName] = useState("");
  const [leadEmail, setLeadEmail] = useState("");
  const [leadPhone, setLeadPhone] = useState("");
  const [hasDetectedLead, setHasDetectedLead] = useState(false);
  const [isLeadBooked, setIsLeadBooked] = useState(false);
  const [isBookingLoading, setIsBookingLoading] = useState(false);

  // Scrolling
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Speech Recognition setup
  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const rec = new SpeechRecognition();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = "en-US";

        rec.onstart = () => {
          setIsListening(true);
        };

        rec.onend = () => {
          setIsListening(false);
        };

        rec.onresult = (e: any) => {
          const transcriptText = e.results[0][0].transcript;
          if (transcriptText) {
            setInputVal(transcriptText);
            // Auto submit speech
            handleSendMessage(transcriptText);
          }
        };

        rec.onerror = (e: any) => {
          console.error("Speech Recognition Error:", e);
          setIsListening(false);
        };

        setRecognition(rec);
      }
    }
  }, []);

  // Text-To-Speech Synthesis function
  const speakAgentResponse = (text: string) => {
    if (!voiceEnabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    
    // Cancel active speech
    window.speechSynthesis.cancel();
    
    // Strip metadata blocks from speech
    const cleanText = text.replace(/\[LEAD_DATA_DETECTED:.*?\]/gi, "").trim();
    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    const voices = window.speechSynthesis.getVoices();
    // Prefer Google, MS, or other high fidelity English/multilingual voices
    const selectedVoice = voices.find(v => v.lang.includes("en-US") && v.name.toLowerCase().includes("google"))
                        || voices.find(v => v.lang.includes("en"))
                        || voices[0];
    
    if (selectedVoice) utterance.voice = selectedVoice;
    utterance.rate = 1.05;
    utterance.pitch = 1.05;
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isTyping]);

  // Speech listen toggle
  const toggleListening = () => {
    playClickSound();
    if (!recognition) {
      alert("Speech Recognition API not supported in this browser. Try Chrome/Safari.");
      return;
    }
    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  // Submit messages to backend
  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputVal;
    if (!textToSend.trim()) return;

    playClickSound();
    if (!customText) setInputVal("");

    const newMsg: Message = {
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages(prev => [...prev, newMsg]);
    setIsTyping(true);

    // Map message list to Gemini structure
    const updatedMessagesForAI = [...messages, newMsg].map(m => ({
      role: m.sender === "user" ? "user" : "model",
      parts: [{ text: m.text }]
    }));

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: updatedMessagesForAI })
      });

      const data = await res.json();
      if (data.text) {
        // Detect language response patterns (light simulation of visual auto-detector)
        detectLanguageVibe(textToSend, data.text);

        // Detect if lead info is present in response
        parseLeadDataInResponse(data.text);

        const agentMsg: Message = {
          sender: "agent",
          text: data.text,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        };

        setMessages(prev => [...prev, agentMsg]);
        speakAgentResponse(data.text);
      }
    } catch (err) {
      console.error("AI Widget chat failure:", err);
      setMessages(prev => [
        ...prev,
        {
          sender: "agent",
          text: "I am experiencing quantum connection issues with Aetheric Core Systems. Please try again in a moment.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  // Helper to visually cycle the auto language detector pill
  const detectLanguageVibe = (userText: string, replyText: string) => {
    const txt = (userText + " " + replyText).toLowerCase();
    if (txt.includes("sindhi") || txt.includes("ڀلي") || txt.includes("ڪري") || txt.includes("آيا")) {
      setLanguageDetected("SINDHI (PUNJABI/SINDH MATRIX)");
    } else if (txt.includes("french") || txt.includes("bonjour") || txt.includes("service")) {
      setLanguageDetected("FRENCH (EURO ZONE)");
    } else if (txt.includes("spanish") || txt.includes("hola") || txt.includes("gracias")) {
      setLanguageDetected("SPANISH (LATAM INDEX)");
    } else if (txt.includes("german") || txt.includes("hallo") || txt.includes("danke")) {
      setLanguageDetected("GERMAN (EU WEST)");
    } else {
      setLanguageDetected("ENGLISH (US/GLOBAL)");
    }
  };

  // Parsing leads using regular expressions
  const parseLeadDataInResponse = (text: string) => {
    // Looks for: [LEAD_DATA_DETECTED: Name: John Doe, Email: john@doe.org, Phone: 0331-1234567]
    const regex = /\[LEAD_DATA_DETECTED:\s*Name:\s*([^,]+),\s*Email:\s*([^,]+),\s*Phone:\s*([^\]]+)\]/i;
    const match = text.match(regex);
    if (match) {
      setLeadName(match[1].trim());
      setLeadEmail(match[2].trim());
      setLeadPhone(match[3].trim());
      setHasDetectedLead(true);
      playSuccessSound();
    }
  };

  // Final Book Order Trigger to Backend (routes n8n, triggers email & WhatsApp)
  const handleFinalOrderConfirm = async () => {
    setIsBookingLoading(true);
    playClickSound();
    try {
      const response = await fetch("/api/ai/book-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: leadName,
          clientEmail: leadEmail,
          clientPhone: leadPhone,
          selectedTier: "AI & Automation Agents",
          projectIdea: "Secured client lead automatically via Conversational AI Chat Widget."
        })
      });

      const data = await response.json();
      if (data.success) {
        setIsLeadBooked(true);
        playSuccessSound();
        // Insert confirmation message to chat
        setMessages(prev => [
          ...prev,
          {
            sender: "agent",
            text: `[SYSTEM BROADCAST] Project Booking Signal sent! Real-time alerts successfully routed to founders at wjunejo@gmail.com and 0331249213. We will finalize your specs soon!`,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          }
        ]);
      }
    } catch (err) {
      console.error("Failed to book order:", err);
      alert("Connection failure. Unable to submit booking.");
    } finally {
      setIsBookingLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans flex flex-col items-end">
      {/* 1. COLLAPSED FLOATING BUTTON */}
      {!isOpen && (
        <button
          onClick={() => {
            playClickSound();
            setIsOpen(true);
          }}
          onMouseEnter={playHoverSound}
          id="floating_ai_widget_trigger"
          className="relative group p-4 rounded-full bg-gradient-to-tr from-cyber-blue via-cyber-purple to-cyber-pink shadow-xl hover:scale-105 active:scale-95 transition-all duration-300 flex items-center justify-center animate-pulse"
          style={{ boxShadow: "0 0 25px rgba(0, 210, 255, 0.45)" }}
        >
          <MessageSquare className="w-6 h-6 text-black" />
          
          {/* Subtle tag overlay */}
          <span className="absolute -top-10 right-0 bg-black/80 border border-cyber-blue/30 text-cyber-blue text-[10px] font-mono px-2 py-0.5 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            TALK TO CO-FOUNDER BOT
          </span>
        </button>
      )}

      {/* 2. EXPANDED GLASSMORPHIC PANEL */}
      {isOpen && (
        <div 
          id="floating_ai_widget_panel"
          className="w-[360px] sm:w-[400px] h-[550px] rounded-2xl glass-panel border border-white/10 flex flex-col shadow-2xl relative overflow-hidden animate-slide-up"
          style={{ background: "rgba(5, 5, 8, 0.95)" }}
        >
          {/* Neon grid decorative overlay */}
          <div className="absolute inset-0 cyber-grid-dense opacity-5 pointer-events-none" />

          {/* Widget Header */}
          <div className="p-4 bg-white/[0.02] border-b border-white/5 relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-cyber-blue/10 border border-cyber-blue/30 flex items-center justify-center relative">
                <Bot className="w-4 h-4 text-cyber-blue" />
                <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-green-500 border border-[#050508] animate-ping" />
              </div>
              <div>
                <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider flex items-center gap-1.5">
                  AETHERIC AI SALES REP <Sparkles className="w-3 h-3 text-cyber-pink animate-pulse" />
                </h4>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">
                    {languageDetected}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Voice toggle */}
              <button
                onClick={() => {
                  playClickSound();
                  setVoiceEnabled(!voiceEnabled);
                  if (voiceEnabled && typeof window !== "undefined") window.speechSynthesis.cancel();
                }}
                className={`p-1.5 rounded-lg border text-xs transition-all ${
                  voiceEnabled 
                    ? "bg-cyber-purple/15 border-cyber-purple/35 text-cyber-purple" 
                    : "bg-white/5 border-white/10 text-gray-500 hover:text-gray-400"
                }`}
                title={voiceEnabled ? "Mute agent voice" : "Enable agent voice"}
              >
                {voiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              </button>

              <button
                onClick={() => {
                  playClickSound();
                  setIsOpen(false);
                }}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/10 border border-white/10 text-gray-400 hover:text-red-400 transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Mode Tabs */}
          <div className="flex bg-white/[0.01] border-b border-white/5 relative z-10 text-[11px] font-display uppercase tracking-widest font-semibold">
            <button
              onClick={() => {
                playClickSound();
                setActiveTab("chat");
              }}
              className={`flex-1 py-3 text-center transition-all border-b ${
                activeTab === "chat" 
                  ? "text-cyber-blue border-cyber-blue font-bold" 
                  : "text-gray-500 border-transparent hover:text-gray-300"
              }`}
            >
              Text Chat
            </button>
            <button
              onClick={() => {
                playClickSound();
                setActiveTab("voice");
              }}
              className={`flex-1 py-3 text-center transition-all border-b ${
                activeTab === "voice" 
                  ? "text-cyber-pink border-cyber-pink font-bold" 
                  : "text-gray-500 border-transparent hover:text-gray-300"
              }`}
            >
              Live Voice
            </button>
          </div>

          {/* Core Content Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 relative z-10">
            {activeTab === "chat" ? (
              // TEXT CHAT MODE
              <>
                {messages.map((m, idx) => (
                  <div key={idx} className={`flex items-start gap-2 ${m.sender === "user" ? "flex-row-reverse" : ""}`}>
                    <div className={`w-6 h-6 rounded-md flex items-center justify-center text-[10px] border ${
                      m.sender === "user" 
                        ? "bg-cyber-purple/10 border-cyber-purple/30 text-cyber-purple" 
                        : "bg-cyber-blue/10 border-cyber-blue/30 text-cyber-blue"
                    }`}>
                      {m.sender === "user" ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                    </div>

                    <div className="flex flex-col max-w-[75%]">
                      <div className={`p-3 rounded-xl text-xs leading-relaxed ${
                        m.sender === "user"
                          ? "bg-cyber-purple/5 border border-cyber-purple/20 text-white rounded-tr-none"
                          : "bg-white/[0.02] border border-white/10 text-gray-300 rounded-tl-none"
                      }`}>
                        {/* Strip metadata from visual display */}
                        {m.text.replace(/\[LEAD_DATA_DETECTED:.*?\]/gi, "").trim()}
                      </div>
                      <span className={`text-[9px] font-mono text-gray-600 mt-1 ${m.sender === "user" ? "text-right" : ""}`}>
                        {m.timestamp}
                      </span>
                    </div>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex items-start gap-2">
                    <div className="w-6 h-6 rounded-md bg-cyber-blue/10 border border-cyber-blue/30 flex items-center justify-center text-[10px] text-cyber-blue">
                      <Bot className="w-3.5 h-3.5 animate-bounce" />
                    </div>
                    <div className="p-3 bg-white/[0.01] border border-white/5 rounded-xl rounded-tl-none max-w-[75%] flex gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyber-blue animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-cyber-blue animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-cyber-blue animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                )}

                {/* INLINE LEAD CONFIRMATION CARD (DYNAMIC CAPTURE) */}
                {hasDetectedLead && !isLeadBooked && (
                  <div className="border border-green-500/30 bg-green-500/5 rounded-xl p-4 space-y-3 animate-fade-in font-mono text-xs">
                    <div className="flex items-center gap-1.5 text-green-400 font-bold uppercase text-[10px]">
                      <ShieldCheck className="w-4 h-4 text-green-400" />
                      Inquiry Lead Detected
                    </div>
                    <p className="text-[10px] text-gray-400 leading-relaxed">
                      Our Co-founder bot has successfully extracted client details from the context of your chat. Securely transmit order booking specifications:
                    </p>
                    <div className="space-y-1.5 bg-black/60 p-2.5 rounded border border-white/5 text-[11px] text-gray-300">
                      <div><span className="text-cyber-blue">CLIENT_NAME:</span> {leadName}</div>
                      <div><span className="text-cyber-blue">CLIENT_EMAIL:</span> {leadEmail}</div>
                      <div><span className="text-cyber-blue">CLIENT_PHONE:</span> {leadPhone}</div>
                    </div>
                    <button
                      onClick={handleFinalOrderConfirm}
                      disabled={isBookingLoading}
                      className="w-full py-2 bg-green-500 text-black font-display font-bold uppercase rounded text-[10px] tracking-wider hover:brightness-110 transition-all flex items-center justify-center gap-2"
                    >
                      {isBookingLoading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> DISPATCHING BROADCAST...
                        </>
                      ) : (
                        "Confirm & Transmit Booking"
                      )}
                    </button>
                  </div>
                )}

                {isLeadBooked && (
                  <div className="border border-green-500/40 bg-green-500/10 rounded-xl p-4 text-center space-y-2 animate-fade-in">
                    <CheckCircle2 className="w-8 h-8 text-green-400 mx-auto animate-bounce" />
                    <h5 className="font-display font-bold text-white text-xs uppercase tracking-wider">Specs Securely Dispatched!</h5>
                    <p className="text-[10px] text-gray-300 font-mono">
                      Real-time signals logged at <strong>wjunejo@gmail.com</strong> &amp; <strong>0331249213</strong>. Our tech agency founders are reviewing your specifications.
                    </p>
                  </div>
                )}
                <div ref={chatEndRef} />
              </>
            ) : (
              // LIVE VOICE MODE (PULSING MICROPHONE HUD)
              <div className="h-full flex flex-col items-center justify-center space-y-6">
                <div className="text-center space-y-2">
                  <h4 className="font-display font-bold text-sm text-white">Interactive Voice Portal</h4>
                  <p className="text-[11px] text-gray-400 max-w-xs leading-relaxed">
                    Tap the microphone, speak your requirements, and hear our futuristic AI Sales Executive pitch in real time.
                  </p>
                </div>

                {/* Animated Speech Ring */}
                <div className="relative flex items-center justify-center">
                  {isListening && (
                    <>
                      <div className="absolute w-32 h-32 rounded-full border border-cyber-pink/25 animate-ping" />
                      <div className="absolute w-24 h-24 rounded-full border border-cyber-blue/35 animate-pulse" />
                    </>
                  )}
                  
                  <button
                    onClick={toggleListening}
                    className={`w-20 h-20 rounded-full flex items-center justify-center border transition-all duration-300 relative z-10 ${
                      isListening 
                        ? "bg-cyber-pink border-cyber-pink shadow-lg shadow-cyber-pink/35 text-black hover:brightness-110" 
                        : "bg-white/5 border-white/10 hover:border-cyber-blue/40 text-cyber-blue shadow-md hover:shadow-cyber-blue/10"
                    }`}
                  >
                    {isListening ? <Mic className="w-8 h-8" /> : <MicOff className="w-8 h-8 text-gray-400" />}
                  </button>
                </div>

                {/* High-Fidelity Voice Wave Visualizer */}
                <div className="flex items-center justify-center gap-1 h-10 w-full max-w-[240px] px-2 select-none">
                  {Array.from({ length: 15 }).map((_, i) => {
                    const baseHeights = [12, 24, 16, 32, 20, 36, 24, 28, 16, 30, 22, 14, 26, 18, 14];
                    const animDurations = ["0.6s", "0.9s", "0.7s", "1.1s", "0.8s", "1.2s", "0.9s", "1.0s", "0.7s", "1.1s", "0.8s", "0.6s", "0.9s", "0.7s", "0.8s"];
                    const gradientColors = [
                      "from-cyber-blue to-cyan-400",
                      "from-cyber-blue to-cyber-purple",
                      "from-cyber-purple to-cyber-pink",
                      "from-cyber-pink to-red-400",
                      "from-cyber-blue to-cyber-purple"
                    ];
                    const gradientClass = gradientColors[i % gradientColors.length];

                    return (
                      <div
                        key={i}
                        className={`w-1 rounded-full bg-gradient-to-t ${gradientClass} ${
                          isListening ? "animate-voicewave" : "opacity-20"
                        }`}
                        style={{
                          height: `${baseHeights[i]}px`,
                          animationDuration: isListening ? animDurations[i] : undefined,
                          transformOrigin: "center",
                          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                        }}
                      />
                    );
                  })}
                </div>

                <div className="flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-mono text-gray-400">
                  <Clock className="w-3.5 h-3.5 text-cyber-blue" />
                  STATUS: {isListening ? "ACTIVE LISTENING" : "IDLE COLD-STANDBY"}
                </div>

                <div className="w-full max-w-[280px] bg-black/40 border border-white/5 rounded-xl p-3 text-center min-h-[50px] flex items-center justify-center">
                  <p className="text-[10px] font-mono text-gray-500 leading-normal">
                    {isListening ? "Say something like: 'I need a luxury 3D WebGL menu template!'" : "Tap Mic above to initiate speech transduction."}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Input Footer (Chat mode only) */}
          {activeTab === "chat" && (
            <div className="p-3 bg-[#0d0d14] border-t border-white/5 relative z-10 flex items-center gap-2">
              <button
                onClick={toggleListening}
                className={`p-2.5 rounded-lg border transition-all ${
                  isListening 
                    ? "bg-cyber-pink border-cyber-pink text-black" 
                    : "bg-white/5 border-white/10 text-gray-400 hover:text-white"
                }`}
                title="Dictate message"
              >
                <Mic className="w-4 h-4" />
              </button>

              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSendMessage();
                }}
                placeholder="Talk to agency co-founders..."
                className="flex-1 bg-black/40 border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyber-blue transition-all font-mono"
              />

              <button
                onClick={() => handleSendMessage()}
                className="p-2.5 rounded-lg bg-cyber-blue hover:bg-cyber-blue/85 text-black transition-all flex items-center justify-center shadow-md shadow-cyber-blue/15"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
