import React, { useState } from "react";
import { Terminal, Code, Database, Share2, Compass, AlertCircle, Sparkles, MapPin, Search, ArrowRight, UserCheck } from "lucide-react";

type SalesTab = "home" | "shop" | "about" | "contact" | "subscribe" | "map" | "faq";

interface SalesTabMetadata {
  id: SalesTab;
  label: string;
  emoji: string;
  tagline: string;
  frontendNode: string;
  backendNode: string;
  databaseNode: string;
  automationJob: string;
}

export default function EnterpriseTerminal() {
  const [activeTab, setActiveTab] = useState<SalesTab>("home");
  const [typedQuery, setTypedQuery] = useState("");
  const [faqFeedback, setFaqFeedback] = useState<string | null>(null);

  const tabs: SalesTabMetadata[] = [
    {
      id: "home",
      label: "Home Core",
      emoji: "🏠",
      tagline: "Ultra-Fast Edge Delivery & Dynamic Entry Animations",
      frontendNode: "React 19 Server Components + Motion Layout Caching",
      backendNode: "Vite Asset Manifest Route with Brotli-Compressed payloads",
      databaseNode: "In-Memory Redis Session Flags & Locale Caches",
      automationJob: "Edge SEO Refresh: Nightly cron rebuilding site sitemaps and indexing pages on Google automatically."
    },
    {
      id: "shop",
      label: "Shop & Commerce",
      emoji: "🛒",
      tagline: "Synchronized Regional Inventory with Secure Checkout Hooks",
      frontendNode: "Micro-frontend Checkout UI with secure Stripe Frame overlays",
      backendNode: "Express Checkout Router proxying to Stripe API webhooks",
      databaseNode: "Drizzle ORM over Relational Cloud SQL with row-level locks",
      automationJob: "Inventory Threshold Sync: Instantly alerts Slack channels and triggers supply orders if stock drops < 15."
    },
    {
      id: "about",
      label: "About Narrative",
      emoji: "📋",
      tagline: "Immersive History & Core Team Performance Telemetry",
      frontendNode: "Interactive 3D Timeline Grid tracking organizational historical milestones",
      backendNode: "Headless Content Management API delivering real-time team logs",
      databaseNode: "Cloud Firestore read-optimized documents cache",
      automationJob: "Bio Updater: Syncs LinkedIn active co-founder updates directly to our team profile cards."
    },
    {
      id: "contact",
      label: "Contact Flow",
      emoji: "📨",
      tagline: "Lead Influx Webhook Routing & Instant AI Pre-Analysis",
      frontendNode: "Glassmorphic validation fields with real-time budget slider",
      backendNode: "Multi-proxy Lead Endpoint with automatic Gemini project evaluator",
      databaseNode: "Persistent Query Logs containing strict customer profiles",
      automationJob: "n8n Customer Dispatch: Spawns a multi-agent n8n workflow, pushes lead to Hubspot, and alerts co-founders via SMS."
    },
    {
      id: "subscribe",
      label: "Subscribe Core",
      emoji: "🔔",
      tagline: "Automated cron scheduling & segment synchronizers",
      frontendNode: "Micro-input field with instant success transitions & cookies",
      backendNode: "Double Opt-In email verification microservice routing",
      databaseNode: "Segmented email roster containing secure user preferences",
      automationJob: "Cron Campaign Launch: Fires active onboarding tutorials over 7 days to maximize lead conversions."
    },
    {
      id: "map",
      label: "Map Location",
      emoji: "📍",
      tagline: "Dynamic Geofencing & Local Branch Schedulers",
      frontendNode: "Custom WebGL Maps core plotting headquarters & active nodes",
      backendNode: "Express Location distance matrix solver route",
      databaseNode: "Spanner multi-region geo-point database indexer",
      automationJob: "Geo-Fence Alert: Tailors promotional offerings based on client's regional coordinates."
    },
    {
      id: "faq",
      label: "User Queries / FAQ",
      emoji: "❓",
      tagline: "Vector Search Embedding Queries & Real-time AI Answering",
      frontendNode: "Type-ahead semantic filtering card with instant answer expanders",
      backendNode: "Gemini Vector Matcher API returning tailored architectural reports",
      databaseNode: "Pinecone Vector Indexes matching query schemas to solutions",
      automationJob: "FAQ Knowledge Base Expander: Automatically stores novel customer queries and creates suggested answer drafts."
    }
  ];

  const currentTab = tabs.find(t => t.id === activeTab) || tabs[0];

  const handleFaqSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedQuery.trim()) return;
    
    setFaqFeedback("Analyzing query patterns against vector space... Connecting to Gemini...");
    setTimeout(() => {
      setFaqFeedback(`
[AI Core Response]: For "${typedQuery}", we suggest deploying a Tier 3 Full-Stack setup. 
We will implement an Express REST API backend on Cloud Run, synchronized to a PostgreSQL database. 
Additionally, we'll route query leads to your shared inbox using an n8n webhook pipeline, ensuring you and your co-founder never miss a potential customer!
      `);
    }, 1500);
  };

  return (
    <div className="w-full relative bg-dark-surface border border-white/5 rounded-2xl overflow-hidden shadow-2xl">
      {/* Header Bar */}
      <div className="bg-white/[0.02] px-6 py-4 border-b border-white/5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-green-500/80 inline-block" />
          </div>
          <span className="text-xs font-mono text-gray-400">aetheric-enterprise-architecture-core.sh</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyber-pink animate-ping" />
          <span className="text-xs font-mono text-cyber-pink uppercase font-semibold tracking-widest">
            Active Core Console
          </span>
        </div>
      </div>

      {/* Main Terminal Frame */}
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[460px]">
        {/* Left Side: Sales Tab Nav links */}
        <div className="lg:col-span-3 border-r border-white/5 bg-black/40 p-4 space-y-1">
          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest px-3 mb-3">
            Sales-Optimization Tabs
          </p>
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => {
                setActiveTab(t.id);
                setFaqFeedback(null);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-mono transition-all text-left border ${
                activeTab === t.id
                  ? "bg-cyber-pink/10 border-cyber-pink/30 text-cyber-pink"
                  : "bg-transparent border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-white"
              }`}
            >
              <span>{t.emoji}</span>
              <span className="font-semibold">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Right Side: Architecture Inspector */}
        <div className="lg:col-span-9 p-6 md:p-8 flex flex-col justify-between relative bg-radial-gradient-glow-2">
          
          {/* Active Tab Details */}
          <div className="space-y-6">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">{currentTab.emoji}</span>
              <div>
                <span className="text-[10px] font-mono text-cyber-pink uppercase tracking-widest">
                  System Segment Blueprint
                </span>
                <h4 className="text-lg font-display font-bold text-white leading-tight">
                  {currentTab.label} Tab Architecture
                </h4>
              </div>
            </div>

            <p className="text-sm text-gray-300 font-display italic">
              &ldquo;{currentTab.tagline}&rdquo;
            </p>

            {/* Simulated Architecture Map Blocks */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {/* Frontend Node */}
              <div className="p-4 rounded-xl border border-white/5 bg-white/[0.01] flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyber-blue font-bold uppercase mb-2">
                    <Code className="w-3.5 h-3.5" /> Frontend (UI)
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-mono">
                    {currentTab.frontendNode}
                  </p>
                </div>
                <div className="text-[9px] text-gray-600 font-mono mt-3">CLIENT THREAD</div>
              </div>

              {/* Backend Router Node */}
              <div className="p-4 rounded-xl border border-white/5 bg-white/[0.01] flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyber-purple font-bold uppercase mb-2">
                    <Terminal className="w-3.5 h-3.5" /> Express Backend
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-mono">
                    {currentTab.backendNode}
                  </p>
                </div>
                <div className="text-[9px] text-gray-600 font-mono mt-3">API PROXY ROUTE</div>
              </div>

              {/* Database State Node */}
              <div className="p-4 rounded-xl border border-white/5 bg-white/[0.01] flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyber-pink font-bold uppercase mb-2">
                    <Database className="w-3.5 h-3.5" /> Storage Layer
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed font-mono">
                    {currentTab.databaseNode}
                  </p>
                </div>
                <div className="text-[9px] text-gray-600 font-mono mt-3">Cloud SQL / Cache</div>
              </div>
            </div>

            {/* Automated background job banner */}
            <div className="p-4 rounded-xl border border-yellow-500/15 bg-yellow-500/[0.02] flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
              <div>
                <h5 className="text-xs font-mono font-bold text-yellow-500 uppercase">
                  Background Automation Routine (n8n Pipeline)
                </h5>
                <p className="text-xs text-gray-400 leading-relaxed mt-1">
                  {currentTab.automationJob}
                </p>
              </div>
            </div>
          </div>

          {/* Interactive Feature for Map/FAQ Tabs */}
          {activeTab === "faq" && (
            <div className="mt-8 pt-6 border-t border-white/5">
              <h5 className="text-xs font-mono uppercase text-gray-300 tracking-wider mb-3">
                Live Semantic FAQ Sandbox:
              </h5>
              <form onSubmit={handleFaqSubmit} className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    value={typedQuery}
                    onChange={(e) => setTypedQuery(e.target.value)}
                    placeholder="Ask about tech stacks, voice agents, n8n webhook setup..."
                    className="w-full bg-black/60 border border-white/10 rounded-lg py-2 pl-9 pr-4 text-xs text-white focus:outline-none focus:border-cyber-pink transition-all font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-cyber-pink hover:bg-cyber-pink/85 text-white font-mono text-xs rounded-lg transition-all"
                >
                  Analyze
                </button>
              </form>

              {faqFeedback && (
                <div className="mt-3 p-3 bg-black/40 border border-cyber-pink/20 rounded-lg text-[11px] font-mono text-gray-300 leading-relaxed whitespace-pre-line animate-pulse">
                  {faqFeedback}
                </div>
              )}
            </div>
          )}

          {activeTab === "map" && (
            <div className="mt-8 pt-6 border-t border-white/5 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-gray-400">Headquarters Node Location:</span>
                <span className="text-cyber-pink">LAT 37.7749° N, LON 122.4194° W</span>
              </div>
              <div className="h-2 w-full bg-white/5 rounded overflow-hidden relative">
                <div className="absolute top-0 left-0 h-full w-2/3 bg-gradient-to-r from-cyber-blue to-cyber-pink rounded animate-pulse" />
              </div>
              <p className="text-[10px] font-mono text-gray-500">
                Matrix Routing: Dynamic geofencing calculates proximity vectors in real-time, matching local customer client endpoints to our fastest server clusters.
              </p>
            </div>
          )}

          {activeTab !== "faq" && activeTab !== "map" && (
            <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
              <span className="text-xs font-mono text-gray-500">
                SECURE ENDPOINT DISPATCH • STATUS CODE: 200 OK
              </span>
              <span className="flex items-center gap-1.5 text-xs font-mono text-cyber-pink font-bold">
                Fully Responsive Modules <Share2 className="w-3.5 h-3.5" />
              </span>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
