export interface LeadQuery {
  id: string;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  selectedTier: string;
  projectIdea: string;
  budgetRange: string;
  createdAt: string;
  aiFeedback?: string;
}

export interface ServiceTier {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  techStack: string[];
  features: string[];
  accentColor: string;
  iconName: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  industry: string;
  description: string;
  badge: string;
  image: string;
  accent: string;
  specs: { label: string; value: string }[];
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: "AI" | "3D Web" | "General";
}
