// Programmatic high-quality synthesized sound effects using Web Audio API

let audioCtx: AudioContext | null = null;
let isMuted = false;

// Safe lazy initialization of AudioContext
const getAudioContext = (): AudioContext | null => {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
};

export const toggleMute = (): boolean => {
  isMuted = !isMuted;
  try {
    localStorage.setItem("cyber_sound_muted", isMuted ? "true" : "false");
  } catch (e) {
    // ignore
  }
  return isMuted;
};

export const getMutedStatus = (): boolean => {
  if (typeof window !== "undefined") {
    try {
      const stored = localStorage.getItem("cyber_sound_muted");
      if (stored !== null) {
        isMuted = stored === "true";
      }
    } catch (e) {
      // ignore
    }
  }
  return isMuted;
};

// 1. Hover sound: extremely subtle, ultra-short high click
export const playHoverSound = () => {
  if (isMuted) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = "sine";
  osc.frequency.setValueAtTime(2200, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(1000, ctx.currentTime + 0.04);

  gain.gain.setValueAtTime(0.008, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.04);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start();
  osc.stop(ctx.currentTime + 0.045);
};

// 2. Click sound: crisp sci-fi pop/chirp
export const playClickSound = () => {
  if (isMuted) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = "triangle";
  osc.frequency.setValueAtTime(800, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.08);

  gain.gain.setValueAtTime(0.02, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.08);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start();
  osc.stop(ctx.currentTime + 0.09);
};

// 3. Success sound: upward synth chime/sweep
export const playSuccessSound = () => {
  if (isMuted) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  
  // Note 1
  const osc1 = ctx.createOscillator();
  const gain1 = ctx.createGain();
  osc1.type = "sine";
  osc1.frequency.setValueAtTime(523.25, now); // C5
  osc1.frequency.exponentialRampToValueAtTime(1046.5, now + 0.2); // C6
  gain1.gain.setValueAtTime(0.015, now);
  gain1.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);
  osc1.connect(gain1);
  gain1.connect(ctx.destination);
  osc1.start(now);
  osc1.stop(now + 0.3);

  // Note 2 (slightly offset perfect fifth)
  const osc2 = ctx.createOscillator();
  const gain2 = ctx.createGain();
  osc2.type = "sine";
  osc2.frequency.setValueAtTime(783.99, now + 0.06); // G5
  osc2.frequency.exponentialRampToValueAtTime(1567.98, now + 0.26); // G6
  gain2.gain.setValueAtTime(0.012, now + 0.06);
  gain2.gain.exponentialRampToValueAtTime(0.0001, now + 0.3);
  osc2.connect(gain2);
  gain2.connect(ctx.destination);
  osc2.start(now + 0.06);
  osc2.stop(now + 0.32);
};
