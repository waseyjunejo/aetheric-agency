import React, { useState, useEffect, useRef } from "react";
import { 
  Cpu, Layers, Globe, Mail, Phone, MapPin, Search, ArrowRight, CheckCircle2, 
  Terminal, ShieldCheck, Database, Zap, RefreshCw, Send, Plus, ArrowUpRight, 
  Users, Activity, Lock, ChevronDown, Check, Star, ExternalLink, HelpCircle, Sparkles,
  Volume2, VolumeX
} from "lucide-react";
import { SERVICE_TIERS, PORTFOLIO_ITEMS, FAQ_ITEMS } from "./data";
import { LeadQuery } from "./types";
import InteractiveDemos from "./components/InteractiveDemos";
import EnterpriseTerminal from "./components/EnterpriseTerminal";
import { ScrollReveal } from "./components/ScrollReveal";
import LiveVoiceAgent from "./components/LiveVoiceAgent";
import AIChatWidget from "./components/AIChatWidget";
import { playClickSound, playHoverSound, playSuccessSound, toggleMute, getMutedStatus } from "./utils/audio";

// --- INTERACTIVE GLOBAL COSMIC BACKGROUND CANVAS COMPONENT ---
interface StarParticle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  maxOpacity: number;
  phase: number;
  freq: number;
}

function GlobalBackgroundCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    const stars: StarParticle[] = [];
    const count = 80;

    for (let i = 0; i < count; i++) {
      stars.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 1.5 + 0.5,
        speedY: -(Math.random() * 0.12 + 0.04), // slow drifting upwards
        speedX: (Math.random() * 0.08 - 0.04), // subtle horizontal sway
        maxOpacity: Math.random() * 0.35 + 0.1,
        phase: Math.random() * Math.PI * 2,
        freq: Math.random() * 0.015 + 0.005
      });
    }

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw subtle drifting cosmic nodes
      stars.forEach(star => {
        star.y += star.speedY;
        star.x += star.speedX;

        // Wrap around boundaries
        if (star.y < 0) {
          star.y = height;
          star.x = Math.random() * width;
        }
        if (star.x < 0) star.x = width;
        if (star.x > width) star.x = 0;

        // Dynamic twinkle
        star.phase += star.freq;
        const opacity = Math.max(0.02, star.maxOpacity * (0.3 + 0.7 * Math.sin(star.phase)));

        ctx.fillStyle = `rgba(0, 210, 255, ${opacity})`;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw fragile connection filaments between nearby stars (for extra sci-fi feel)
      ctx.strokeStyle = "rgba(188, 19, 254, 0.025)";
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      for (let i = 0; i < count; i++) {
        for (let j = i + 1; j < count; j++) {
          const dist = Math.hypot(stars[i].x - stars[j].x, stars[i].y - stars[j].y);
          if (dist < 130) {
            ctx.moveTo(stars[i].x, stars[i].y);
            ctx.lineTo(stars[j].x, stars[j].y);
          }
        }
      }
      ctx.stroke();

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 w-full h-full pointer-events-none z-[1] opacity-60" 
    />
  );
}

// --- INTERACTIVE BACKGROUND STAR/PARTICLE CORE COMPONENT ---
interface Particle {
  x: number;
  y: number;
  r: number;
  speed: number;
  angle: number;
  color: string;
}

interface EmanatingParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  alpha: number;
  maxLife: number;
  life: number;
  color: string;
}

function TechCoreCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let width = canvas.width = canvas.offsetWidth;
    let height = canvas.height = canvas.offsetHeight;

    const particles: Particle[] = [];
    const count = 50;
    const colors = ["#00d2ff", "#bc13fe", "#ff00c1"]; // updated to immersive design palette

    for (let i = 0; i < count; i++) {
      const radius = Math.random() * 85 + 45;
      const angle = Math.random() * Math.PI * 2;
      particles.push({
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        r: Math.random() * 1.8 + 1,
        speed: (Math.random() * 0.008 + 0.003) * (Math.random() > 0.5 ? 1 : -1),
        angle: angle,
        color: colors[i % colors.length]
      });
    }

    // Emanating energy sparks radiating out of the center core
    let emanatingParticles: EmanatingParticle[] = [];

    const handleMouseMove = (e: MouseEvent) => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      mouseRef.current.targetX = e.clientX - rect.left - width / 2;
      mouseRef.current.targetY = e.clientY - rect.top - height / 2;
    };

    window.addEventListener("mousemove", handleMouseMove);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", handleResize);

    let tick = 0;
    const render = () => {
      tick++;
      ctx.clearRect(0, 0, width, height);
      ctx.save();
      ctx.translate(width / 2, height / 2);

      // Smooth mouse tracking
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.08;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.08;

      // Spawn subtle energy sparks emanating outwards
      if (tick % 4 === 0) {
        const angle = Math.random() * Math.PI * 2;
        const sparkColor = colors[Math.floor(Math.random() * colors.length)];
        const speed = Math.random() * 0.9 + 0.4;
        emanatingParticles.push({
          x: (Math.random() - 0.5) * 10,
          y: (Math.random() - 0.5) * 10,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          r: Math.random() * 1.5 + 0.5,
          alpha: 1.0,
          maxLife: Math.floor(Math.random() * 80) + 60,
          life: 0,
          color: sparkColor
        });
      }

      // Draw counter-rotating orbit grid lines representing quantum/tech layers
      // Layer 1: Clockwise Outer Core Ring
      ctx.save();
      ctx.rotate(tick * 0.001);
      ctx.strokeStyle = "rgba(0, 210, 255, 0.12)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, 115, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Layer 2: Counter-Clockwise Dash Orbit Grid
      ctx.save();
      ctx.rotate(-tick * 0.0015);
      ctx.strokeStyle = "rgba(188, 19, 254, 0.16)";
      ctx.setLineDash([5, 12]);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, 150, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      // Layer 3: Slow Wave Ring
      ctx.save();
      ctx.rotate(tick * 0.0006);
      ctx.strokeStyle = "rgba(255, 0, 193, 0.08)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, 190, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Orbiting Satellite Node orbiting on Layer 2
      ctx.save();
      ctx.rotate(tick * 0.004);
      const satX = Math.cos(tick * 0.008) * 150;
      const satY = Math.sin(tick * 0.008) * 60; // tilted ellipse path
      ctx.fillStyle = "#00d2ff";
      ctx.shadowBlur = 12;
      ctx.shadowColor = "#00d2ff";
      ctx.beginPath();
      ctx.arc(satX, satY, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.restore();

      // Draw subtle connecting digital web
      ctx.beginPath();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.025)";
      for (let i = 0; i < count; i += 2) {
        if (i + 1 < count) {
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[i + 1].x, particles[i + 1].y);
        }
      }
      ctx.stroke();

      // Render & Update emanating spark/particles
      emanatingParticles.forEach((p, idx) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life++;
        p.alpha = 1.0 - (p.life / p.maxLife);

        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 6;
        ctx.shadowColor = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });
      // Filter out expired energy particles
      emanatingParticles = emanatingParticles.filter(p => p.life < p.maxLife);

      // Rotate and draw constellation particles
      ctx.save();
      ctx.rotate(tick * 0.0008);
      particles.forEach(p => {
        p.angle += p.speed;
        const currentRadius = Math.sqrt(p.x * p.x + p.y * p.y);
        
        // Update particle coords with rotation & subtle mouse displacement
        const targetX = Math.cos(p.angle) * currentRadius + mouseRef.current.x * 0.18;
        const targetY = Math.sin(p.angle) * currentRadius + mouseRef.current.y * 0.18;

        ctx.fillStyle = p.color;
        ctx.shadowBlur = 10;
        ctx.shadowColor = p.color;
        ctx.beginPath();
        ctx.arc(targetX, targetY, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0; // reset
      });
      ctx.restore();

      // Draw Central pulsating glow/halo of tech core
      const pulseFactor = Math.sin(tick * 0.04) * 0.15 + 1.0; // Oscillates smoothly
      const coreSize = 54 * pulseFactor;

      const radialGlow = ctx.createRadialGradient(0, 0, 0, 0, 0, coreSize);
      radialGlow.addColorStop(0, "rgba(0, 210, 255, 0.45)");
      radialGlow.addColorStop(0.4, "rgba(188, 19, 254, 0.22)");
      radialGlow.addColorStop(1, "transparent");
      
      ctx.fillStyle = radialGlow;
      ctx.beginPath();
      ctx.arc(0, 0, coreSize * 1.3, 0, Math.PI * 2);
      ctx.fill();

      // Inner high-intensity nucleus
      const coreNucleus = ctx.createRadialGradient(0, 0, 0, 0, 0, 18);
      coreNucleus.addColorStop(0, "#ffffff");
      coreNucleus.addColorStop(0.5, "rgba(255, 0, 193, 0.85)");
      coreNucleus.addColorStop(1, "rgba(188, 19, 254, 0)");
      ctx.fillStyle = coreNucleus;
      ctx.beginPath();
      ctx.arc(0, 0, 22, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full h-full relative overflow-hidden flex items-center justify-center">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
}

export default function App() {
  // --- GENERAL STATE CONTROLS ---
  const [activeFAQ, setActiveFAQ] = useState<string | null>("faq-1");
  const [selectedPortfolioId, setSelectedPortfolioId] = useState<string>("fast-food");
  const [emailSubbed, setEmailSubbed] = useState(false);
  const [subbedEmail, setSubbedEmail] = useState("");
  const [soundMuted, setSoundMuted] = useState(getMutedStatus());

  // --- CONSULTATION FORM STATES ---
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [selectedTier, setSelectedTier] = useState("AI & Automation Agents");
  const [projectIdea, setProjectIdea] = useState("");
  const [budgetRange, setBudgetRange] = useState("$10,000 - $25,000");

  const [aiAnalysisResult, setAiAnalysisResult] = useState<string | null>(null);
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [formSuccess, setFormSuccess] = useState(false);

  // --- CO-FOUNDERS LOGS CONTROL HUD ---
  const [showCoFoundersHud, setShowCoFoundersHud] = useState(false);
  const [leadList, setLeadList] = useState<LeadQuery[]>([]);
  const [hudLoading, setHudLoading] = useState(false);
  const [stats, setStats] = useState({
    activeInquiries: 2,
    conversionRatio: "92%",
    serverPings: "12ms",
    nodeHealth: "100%"
  });

  // Tilt states for glass panels in hero section
  const [mouseTilt, setMouseTilt] = useState({ rx: 0, ry: 0 });

  const handleHeroMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    // Calculate tilt angles max 15deg
    const rx = -(y / (rect.height / 2)) * 12;
    const ry = (x / (rect.width / 2)) * 12;
    setMouseTilt({ rx, ry });
  };

  const handleHeroMouseLeave = () => {
    setMouseTilt({ rx: 0, ry: 0 });
  };

  // Fetch submitted inquiries from Express server for the co-founders dashboard
  const fetchLeads = async () => {
    setHudLoading(true);
    try {
      const response = await fetch("/api/consult/list");
      const data = await response.json();
      if (data.success) {
        setLeadList(data.leads);
        // Calculate dynamic stats
        setStats(prev => ({
          ...prev,
          activeInquiries: data.leads.length
        }));
      }
    } catch (err) {
      console.error("Error loading inquiries list:", err);
    } finally {
      setHudLoading(false);
    }
  };

  useEffect(() => {
    if (showCoFoundersHud) {
      fetchLeads();
    }
  }, [showCoFoundersHud]);

  // AI Architect consultation blueprint trigger
  const handleAiBlueprintSynthesis = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (!projectIdea.trim()) {
      alert("Please describe your project idea or technology goals first!");
      return;
    }

    setAiAnalyzing(true);
    setAiAnalysisResult(null);

    try {
      const res = await fetch("/api/ai/analyze-project", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectIdea, selectedTier })
      });
      const data = await res.json();
      if (data.response) {
        setAiAnalysisResult(data.response);
        playSuccessSound();
      } else {
        setAiAnalysisResult("Failed to retrieve blueprint. Server was unable to synthesize the prompt response.");
      }
    } catch (err) {
      console.error("Blueprint error:", err);
      setAiAnalysisResult("API Connection issues. Neural core returned fallback protocols.");
    } finally {
      setAiAnalyzing(false);
    }
  };

  // Process Lead Submission
  const handleLeadFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName || !clientEmail || !projectIdea) {
      alert("Please enter your name, email, and project description!");
      return;
    }

    try {
      const response = await fetch("/api/consult/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName,
          clientEmail,
          selectedTier,
          projectIdea,
          budgetRange,
          aiFeedback: aiAnalysisResult || undefined
        })
      });

      const data = await response.json();
      if (data.success) {
        setFormSuccess(true);
        playSuccessSound();
        // Reset inputs
        setClientName("");
        setClientEmail("");
        setProjectIdea("");
        setAiAnalysisResult(null);
        // Re-fetch list if dashboard is active
        if (showCoFoundersHud) {
          fetchLeads();
        }
        setTimeout(() => {
          setFormSuccess(false);
          // Scroll smoothly to top
          window.scrollTo({ top: 0, behavior: "smooth" });
        }, 5000);
      }
    } catch (err) {
      console.error("Submit lead failure:", err);
      alert("An issue occurred sending your request. Try again shortly.");
    }
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subbedEmail) return;
    setEmailSubbed(true);
    setTimeout(() => {
      setEmailSubbed(false);
      setSubbedEmail("");
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white cyber-grid relative font-sans overflow-x-hidden">
      
      {/* GLOBAL COSMIC BACKGROUND ANIMATION */}
      <GlobalBackgroundCanvas />
      
      {/* BACKGROUND ACCENT ORBS */}
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />

      {/* --- STICKY NAVIGATION BAR --- */}
      <header className="sticky top-0 z-50 w-full bg-black/40 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyber-blue to-cyber-purple p-[1px] shadow-lg shadow-cyber-blue/20">
              <div className="w-full h-full bg-[#07070c] rounded-[11px] flex items-center justify-center">
                <Cpu className="w-5 h-5 text-cyber-blue group-hover:rotate-45 transition-transform duration-500" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-lg tracking-wider text-white">
                AETHERIC<span className="text-cyber-blue font-mono font-medium text-xs ml-1.5 px-1.5 py-0.5 bg-cyber-blue/10 rounded border border-cyber-blue/20">STUDIOS</span>
              </span>
              <span className="text-[9px] font-mono tracking-widest text-gray-500 uppercase">
                AI & 3D WEB ARCHITECTS
              </span>
            </div>
          </a>

          {/* Nav Links */}
          <nav className="hidden md:flex items-center gap-8">
            <a 
              href="#home" 
              onMouseEnter={playHoverSound}
              onClick={playClickSound}
              className="text-[11px] font-display font-semibold uppercase tracking-widest text-gray-300 hover:text-cyber-blue transition-colors"
            >
              Home
            </a>
            <a 
              href="#services" 
              onMouseEnter={playHoverSound}
              onClick={playClickSound}
              className="text-[11px] font-display font-semibold uppercase tracking-widest text-gray-300 hover:text-cyber-blue transition-colors"
            >
              Services
            </a>
            <a 
              href="#portfolio" 
              onMouseEnter={playHoverSound}
              onClick={playClickSound}
              className="text-[11px] font-display font-semibold uppercase tracking-widest text-gray-300 hover:text-cyber-blue transition-colors"
            >
              Portfolio
            </a>
            <a 
              href="#contact" 
              onMouseEnter={playHoverSound}
              onClick={playClickSound}
              className="text-[11px] font-display font-semibold uppercase tracking-widest text-gray-300 hover:text-cyber-blue transition-colors"
            >
              Contact
            </a>
          </nav>

          {/* Glowing CTA Button */}
          <div className="flex items-center gap-4">
            {/* Audio Toggle Button */}
            <button
              onMouseEnter={playHoverSound}
              onClick={() => {
                const muted = toggleMute();
                setSoundMuted(muted);
                playClickSound();
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono transition-all ${
                !soundMuted 
                  ? "bg-cyber-blue/10 border-cyber-blue/30 text-cyber-blue" 
                  : "bg-white/5 border-white/10 text-gray-500 hover:text-gray-400"
              }`}
              title={soundMuted ? "Unmute sound effects" : "Mute sound effects"}
            >
              {soundMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{soundMuted ? "MUTE" : "AUDIO"}</span>
            </button>

            {/* Toggle Co-Founders Hud */}
            <button
              onMouseEnter={playHoverSound}
              onClick={() => {
                playClickSound();
                setShowCoFoundersHud(!showCoFoundersHud);
              }}
              className={`hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg border text-xs font-mono transition-all ${
                showCoFoundersHud 
                  ? "bg-cyber-pink/20 border-cyber-pink text-cyber-pink shadow-lg shadow-cyber-pink/10" 
                  : "bg-white/5 border-white/10 text-gray-400 hover:border-cyber-pink/30 hover:text-cyber-pink"
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              HUD: {showCoFoundersHud ? "ON" : "OFF"}
            </button>

            <a
              href="#contact"
              onMouseEnter={playHoverSound}
              onClick={playClickSound}
              className="relative px-5 py-2.5 rounded-lg text-xs font-display font-bold uppercase tracking-widest text-black bg-gradient-to-r from-cyber-blue to-cyber-purple hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-cyber-blue/20"
            >
              Get a Quote
            </a>
          </div>

        </div>
      </header>

      {/* --- CO-FOUNDERS OVERLAY HUD CONTROL PANEL --- */}
      {showCoFoundersHud && (
        <section className="bg-black/90 border-b border-cyber-pink/20 relative z-40 animate-fade-in">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-6 mb-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyber-pink animate-ping" />
                  <h3 className="text-sm font-mono font-bold uppercase tracking-widest text-cyber-pink">
                    Agency founders Telemetry Panel
                  </h3>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  Active workspace for you and your co-founder. Monitor customer queries, AI key validations, and active server routes.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={fetchLeads}
                  disabled={hudLoading}
                  className="p-2 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-all disabled:opacity-50"
                  title="Force telemetry refresh"
                >
                  <RefreshCw className={`w-4 h-4 ${hudLoading ? "animate-spin" : ""}`} />
                </button>
                <button
                  onClick={() => setShowCoFoundersHud(false)}
                  className="px-3 py-1.5 rounded bg-white/5 hover:bg-red-500/10 text-gray-400 hover:text-red-400 text-xs font-mono transition-all"
                >
                  Close [X]
                </button>
              </div>
            </div>

            {/* Metrics Dashboard */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="p-4 bg-white/[0.01] border border-white/5 rounded-xl">
                <span className="text-[10px] font-mono text-gray-500 uppercase block">Active Project Queries</span>
                <span className="text-2xl font-mono font-bold text-cyber-blue mt-1 block">{stats.activeInquiries}</span>
              </div>
              <div className="p-4 bg-white/[0.01] border border-white/5 rounded-xl">
                <span className="text-[10px] font-mono text-gray-500 uppercase block">Client Target Match</span>
                <span className="text-2xl font-mono font-bold text-cyber-purple mt-1 block">{stats.conversionRatio}</span>
              </div>
              <div className="p-4 bg-white/[0.01] border border-white/5 rounded-xl">
                <span className="text-[10px] font-mono text-gray-500 uppercase block">Node Ingress latency</span>
                <span className="text-2xl font-mono font-bold text-cyber-pink mt-1 block">{stats.serverPings}</span>
              </div>
              <div className="p-4 bg-white/[0.01] border border-white/5 rounded-xl">
                <span className="text-[10px] font-mono text-gray-500 uppercase block">Gemini Sync Gateway</span>
                <span className="text-2xl font-mono font-bold text-green-400 mt-1 block flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-400 inline" /> {stats.nodeHealth}
                </span>
              </div>
            </div>

            {/* Lead list block */}
            <div className="bg-dark-surface/60 border border-white/5 rounded-xl overflow-hidden">
              <div className="px-5 py-3 bg-white/[0.02] border-b border-white/5 text-xs font-mono text-gray-400 flex justify-between">
                <span>INCOMING CLIENT CONSULTATION QUEUE</span>
                <span>TELEMETRY STACK: EXPRESS + DISPATCH</span>
              </div>

              {leadList.length === 0 ? (
                <div className="p-12 text-center text-gray-500 text-xs font-mono">
                  No consultation requests received yet. Fill out the contact form below to test!
                </div>
              ) : (
                <div className="divide-y divide-white/5 max-h-[350px] overflow-y-auto">
                  {leadList.map(lead => (
                    <div key={lead.id} className="p-5 hover:bg-white/[0.01] transition-all">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-display font-bold text-white text-sm">{lead.clientName}</span>
                            <span className="text-[10px] font-mono px-2 py-0.5 bg-cyber-blue/10 border border-cyber-blue/20 text-cyber-blue rounded">
                              {lead.selectedTier}
                            </span>
                            <span className="text-[10px] font-mono text-gray-500">{lead.clientEmail}</span>
                          </div>
                          <p className="text-xs text-gray-400 mt-2 font-mono leading-relaxed max-w-4xl">
                            &ldquo;{lead.projectIdea}&rdquo;
                          </p>

                          {lead.aiFeedback && (
                            <div className="mt-3 p-3.5 bg-cyber-pink/[0.02] border border-cyber-pink/10 rounded-lg text-xs font-mono text-gray-400 leading-relaxed whitespace-pre-line">
                              <span className="text-cyber-pink font-bold uppercase text-[10px] block mb-1">
                                [AI ARCHITECT SPECIFICATION SUMMARY]
                              </span>
                              {lead.aiFeedback.length > 250 ? lead.aiFeedback.substring(0, 250) + "..." : lead.aiFeedback}
                            </div>
                          )}
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] font-mono text-gray-500 block">EST BUDGET</span>
                          <span className="text-xs font-mono font-bold text-green-400 block mt-1">{lead.budgetRange}</span>
                          <span className="text-[9px] font-mono text-gray-600 block mt-1.5">
                            {new Date(lead.createdAt).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* --- HERO SECTION --- */}
      <section
        id="home"
        onMouseMove={handleHeroMouseMove}
        onMouseLeave={handleHeroMouseLeave}
        className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center overflow-hidden min-h-[calc(100vh-80px)]"
      >
        {/* Left Side: Copywriting */}
        <div className="lg:col-span-6 space-y-8 z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-cyber-blue/5 border border-cyber-blue/25 rounded-full text-cyber-blue text-xs font-mono tracking-wider">
            <span className="w-2 h-2 rounded-full bg-cyber-blue animate-pulse" />
            IMMERSIBLE EXPERIENCE GENERATION
          </div>

          <h1 className="text-4xl sm:text-5xl xl:text-6xl font-display font-extrabold tracking-tight text-white leading-tight">
            We Build the Future of the Web:
            <span className="block mt-2 bg-gradient-to-r from-cyber-blue via-cyber-purple to-cyber-pink bg-clip-text text-transparent glow-text-blue">
              3D Websites & AI Automation
            </span>
          </h1>

          <p className="text-base sm:text-lg text-gray-400 max-w-xl leading-relaxed">
            We engineer high-fidelity, interactive digital realms. Specializing in responsive WebGL layouts, robust autonomous voice agents, and full sales-optimized enterprise solutions for modern brands.
          </p>

          {/* Dual Action Buttons */}
          <div className="flex flex-wrap gap-4 pt-2">
            <a
              href="#contact"
              onMouseEnter={playHoverSound}
              onClick={playClickSound}
              className="px-6 py-3.5 bg-cyber-blue hover:bg-cyber-blue/85 text-black font-display font-bold text-xs uppercase tracking-wider rounded-lg transition-all shadow-lg shadow-cyber-blue/25 flex items-center gap-2"
            >
              Initiate Quote <Send className="w-4 h-4" />
            </a>
            <a
              href="#services"
              onMouseEnter={playHoverSound}
              onClick={playClickSound}
              className="px-6 py-3.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-display font-bold text-xs uppercase tracking-wider rounded-lg transition-all flex items-center gap-2"
            >
              Explore Showroom <ArrowRight className="w-4 h-4 text-cyber-blue" />
            </a>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-3 gap-6 pt-8 border-t border-white/5">
            <div>
              <span className="text-2xl sm:text-3xl font-display font-bold text-white block">98%</span>
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider mt-1 block">Automation Rate</span>
            </div>
            <div>
              <span className="text-2xl sm:text-3xl font-display font-bold text-white block">0.4s</span>
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider mt-1 block">Average Render Latency</span>
            </div>
            <div>
              <span className="text-2xl sm:text-3xl font-display font-bold text-white block">$4.8M+</span>
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider mt-1 block">Client Revenue Generated</span>
            </div>
          </div>
        </div>

        {/* Right Side: Central Visual Area (Interactive 3D Particle Core & Cohesive Pillars Grid) */}
        <div className="lg:col-span-6 flex flex-col items-center gap-8 z-10">
          
          {/* Main 3D Tilting Panel Wrapper */}
          <div 
            className="w-full max-w-[440px] aspect-square rounded-2xl border border-white/10 bg-[#05050a]/80 backdrop-blur-lg relative overflow-hidden shadow-2xl transition-transform duration-200"
            style={{
              transform: `perspective(1000px) rotateX(${mouseTilt.rx}deg) rotateY(${mouseTilt.ry}deg)`,
              transformStyle: "preserve-3d"
            }}
          >
            {/* Tech core rendering canvas (Full opacity, absolute primary focus) */}
            <div className="absolute inset-0 z-0">
              <TechCoreCanvas />
            </div>

            {/* Subtle elegant glass overlay tag to complement the 3D core canvas */}
            <div className="absolute top-4 left-4 z-10 bg-black/60 backdrop-blur-md border border-white/10 rounded-lg px-3 py-1.5 text-[10px] font-mono text-cyber-blue flex items-center gap-1.5 shadow-lg select-none">
              <span className="w-1.5 h-1.5 rounded-full bg-cyber-blue animate-pulse" />
              <span>INTERACTIVE_3D_CORE</span>
            </div>

            <div className="absolute bottom-4 right-4 z-10 bg-black/60 backdrop-blur-md border border-white/10 rounded-lg px-3 py-1.5 text-[10px] font-mono text-cyber-purple flex items-center gap-1.5 shadow-lg select-none">
              <span className="w-1.5 h-1.5 rounded-full bg-cyber-purple animate-pulse" />
              <span>LIVE_PARTICLE_RENDER</span>
            </div>

            {/* Minimalist framing/corner highlights to emphasize design precision */}
            <div className="absolute top-0 left-0 w-5 h-5 border-t border-l border-cyber-blue/30 rounded-tl-2xl pointer-events-none" />
            <div className="absolute top-0 right-0 w-5 h-5 border-t border-r border-cyber-blue/30 rounded-tr-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-5 h-5 border-b border-l border-cyber-blue/30 rounded-bl-2xl pointer-events-none" />
            <div className="absolute bottom-0 right-0 w-5 h-5 border-b border-r border-cyber-blue/30 rounded-br-2xl pointer-events-none" />
          </div>

          {/* High-Fidelity Grid of Agency Core Pillars */}
          <div className="w-full max-w-[440px] grid grid-cols-2 gap-3">
            <div className="glass-panel p-3.5 rounded-xl border border-white/5 bg-white/[0.01] hover:border-cyber-blue/30 hover:bg-cyber-blue/[0.02] transition-all duration-300 group">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="p-1.5 rounded-lg bg-cyber-blue/10 border border-cyber-blue/25 text-cyber-blue group-hover:scale-105 transition-transform">
                  <Globe className="w-3.5 h-3.5" />
                </div>
                <h5 className="font-display font-bold text-xs text-white">3D WebGL Web</h5>
              </div>
              <p className="text-[10px] text-gray-400 font-mono leading-normal">
                Responsive 3D layouts, high render fidelity & smooth frame rates.
              </p>
            </div>

            <div className="glass-panel p-3.5 rounded-xl border border-white/5 bg-white/[0.01] hover:border-cyber-purple/30 hover:bg-cyber-purple/[0.02] transition-all duration-300 group">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="p-1.5 rounded-lg bg-cyber-purple/10 border border-cyber-purple/25 text-cyber-purple group-hover:scale-105 transition-transform">
                  <Cpu className="w-3.5 h-3.5" />
                </div>
                <h5 className="font-display font-bold text-xs text-white">AI Automation</h5>
              </div>
              <p className="text-[10px] text-gray-400 font-mono leading-normal">
                Speech recognition, autonomous sales reps & automated dispatch.
              </p>
            </div>

            <div className="glass-panel p-3.5 rounded-xl border border-white/5 bg-white/[0.01] hover:border-cyber-pink/30 hover:bg-cyber-pink/[0.02] transition-all duration-300 group">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="p-1.5 rounded-lg bg-cyber-pink/10 border border-cyber-pink/25 text-cyber-pink group-hover:scale-105 transition-transform">
                  <Zap className="w-3.5 h-3.5" />
                </div>
                <h5 className="font-display font-bold text-xs text-white">Instant Routing</h5>
              </div>
              <p className="text-[10px] text-gray-400 font-mono leading-normal">
                Decoupled n8n pipelines, SMS broadcasts & direct client notifications.
              </p>
            </div>

            <div className="glass-panel p-3.5 rounded-xl border border-white/5 bg-white/[0.01] hover:border-green-400/30 hover:bg-green-400/[0.02] transition-all duration-300 group">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="p-1.5 rounded-lg bg-green-400/10 border border-green-400/25 text-green-400 group-hover:scale-105 transition-transform">
                  <Terminal className="w-3.5 h-3.5" />
                </div>
                <h5 className="font-display font-bold text-xs text-white">Telemetry Logs</h5>
              </div>
              <p className="text-[10px] text-gray-400 font-mono leading-normal">
                Synchronized telemetry, query states & custom founder analytics.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* --- TRUSTED BY PARTNERS SECTION --- */}
      <ScrollReveal delay={100} duration={1000} className="py-12 bg-black/20 border-y border-white/5 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-[10px] font-mono tracking-widest text-gray-400 uppercase mb-8">
            [ DECOUPLED SYSTEMS & VENTURES INTEGRATED IN PRODUCTION ]
          </p>
          
          {/* Logo Marquee Container */}
          <div className="relative w-full overflow-hidden flex items-center">
            {/* Fade gradients on edges */}
            <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-[#050505] to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-[#050505] to-transparent z-10 pointer-events-none" />
            
            <div className="animate-marquee flex gap-16 md:gap-24 items-center">
              {[1, 2].map((loopIndex) => (
                <React.Fragment key={loopIndex}>
                  {/* Logo 1 */}
                  <div className="flex items-center gap-3 grayscale opacity-45 hover:opacity-100 hover:grayscale-0 hover:text-cyber-blue transition-all duration-300 group cursor-pointer">
                    <svg className="w-5 h-5 text-current transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M12 2L2 12h5v10h10V12h5L12 2z" />
                    </svg>
                    <span className="font-display font-bold text-sm tracking-widest text-white">AETHER_DYNAMICS</span>
                  </div>
                  
                  {/* Logo 2 */}
                  <div className="flex items-center gap-3 grayscale opacity-45 hover:opacity-100 hover:grayscale-0 hover:text-cyber-purple transition-all duration-300 group cursor-pointer">
                    <svg className="w-5 h-5 text-current transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <circle cx="12" cy="12" r="10" />
                      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                      <path d="M2 12h20" />
                    </svg>
                    <span className="font-display font-bold text-sm tracking-widest text-white">VORTEX_NEURAL</span>
                  </div>

                  {/* Logo 3 */}
                  <div className="flex items-center gap-3 grayscale opacity-45 hover:opacity-100 hover:grayscale-0 hover:text-cyber-pink transition-all duration-300 group cursor-pointer">
                    <svg className="w-5 h-5 text-current transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                    </svg>
                    <span className="font-display font-bold text-sm tracking-widest text-white">KRYPTON_SYS</span>
                  </div>

                  {/* Logo 4 */}
                  <div className="flex items-center gap-3 grayscale opacity-45 hover:opacity-100 hover:grayscale-0 hover:text-cyber-blue transition-all duration-300 group cursor-pointer">
                    <svg className="w-5 h-5 text-current transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5" />
                      <line x1="12" y1="2" x2="12" y2="22" />
                      <line x1="12" y1="12" x2="22" y2="8.5" />
                      <line x1="12" y1="12" x2="2" y2="8.5" />
                    </svg>
                    <span className="font-display font-bold text-sm tracking-widest text-white">NEXUS_CORE</span>
                  </div>

                  {/* Logo 5 */}
                  <div className="flex items-center gap-3 grayscale opacity-45 hover:opacity-100 hover:grayscale-0 hover:text-cyber-purple transition-all duration-300 group cursor-pointer">
                    <svg className="w-5 h-5 text-current transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <circle cx="12" cy="12" r="10" />
                      <path d="M4.5 16.5c-1.5 1.25-2.5 3-2.5 5h20c0-2-1-3.75-2.5-5" />
                      <circle cx="12" cy="7" r="4" />
                    </svg>
                    <span className="font-display font-bold text-sm tracking-widest text-white">SYNAPSE_AI</span>
                  </div>
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </ScrollReveal>

      {/* --- SERVICES SHOWROOM --- */}
      <section id="services" className="py-24 bg-black/35 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-mono text-cyber-purple uppercase tracking-widest px-3 py-1 bg-cyber-purple/5 border border-cyber-purple/20 rounded-full">
              INTERACTIVE REVENUE LAYOUTS
            </span>
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mt-4 mb-4">
              Our Services: 3-Tier Interactive Showroom
            </h2>
            <p className="text-sm sm:text-base text-gray-400">
              Hover over our core service tracks. Explore interactive WebGL menus, e-commerce skins, and custom room reservation flows in the demo suite below.
            </p>
          </div>

          {/* Three Tier Cards Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            {SERVICE_TIERS.map((tier, idx) => {
              const isBlue = tier.accentColor === "cyber-blue";
              const isPurple = tier.accentColor === "cyber-purple";
              const isPink = tier.accentColor === "cyber-pink";

              return (
                <ScrollReveal
                  key={tier.id}
                  delay={idx * 120}
                  variant="slide-up"
                  distance={45}
                  className="h-full"
                >
                  <div
                    onMouseEnter={playHoverSound}
                    onClick={playClickSound}
                    className={`glass-panel rounded-2xl p-6 md:p-8 h-full relative overflow-hidden border transition-all duration-300 group cursor-pointer ${
                      isBlue 
                        ? "hover:border-cyber-blue/40 hover:shadow-[0_0_30px_rgba(0,240,255,0.1)]" 
                        : isPurple 
                        ? "hover:border-cyber-purple/40 hover:shadow-[0_0_30px_rgba(189,0,255,0.1)]" 
                        : "hover:border-cyber-pink/40 hover:shadow-[0_0_30px_rgba(255,0,122,0.1)]"
                    }`}
                  >
                  {/* Decorative Gradient Line Top */}
                  <div className={`absolute top-0 left-0 h-1 w-full bg-gradient-to-r ${
                    isBlue 
                      ? "from-cyber-blue to-transparent" 
                      : isPurple 
                      ? "from-cyber-purple to-transparent" 
                      : "from-cyber-pink to-transparent"
                  }`} />

                  {/* Header */}
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">
                        {tier.subtitle}
                      </span>
                      <h3 className="text-xl font-display font-bold text-white mt-1 group-hover:text-white transition-colors">
                        {tier.title}
                      </h3>
                    </div>
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center border bg-white/[0.01] ${
                      isBlue 
                        ? "border-cyber-blue/20 text-cyber-blue" 
                        : isPurple 
                        ? "border-cyber-purple/20 text-cyber-purple" 
                        : "border-cyber-pink/20 text-cyber-pink"
                    }`}>
                      {tier.iconName === "Cpu" ? (
                        <Cpu className="w-5 h-5 animate-pulse" />
                      ) : tier.iconName === "Layers" ? (
                        <Layers className="w-5 h-5" />
                      ) : (
                        <Globe className="w-5 h-5" />
                      )}
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-gray-400 leading-relaxed mb-6">
                    {tier.description}
                  </p>

                  {/* Feature Bullets */}
                  <ul className="space-y-3 mb-8">
                    {tier.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-gray-300">
                        <Check className={`w-4 h-4 shrink-0 mt-0.5 ${
                          isBlue ? "text-cyber-blue" : isPurple ? "text-cyber-purple" : "text-cyber-pink"
                        }`} />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Tech stack badges */}
                  <div className="pt-6 border-t border-white/5">
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block mb-2">
                      SYSTEM INTEGRATION:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {tier.techStack.map((tech, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded bg-white/[0.03] border border-white/5 text-[9px] font-mono text-gray-400">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  </div>
                </ScrollReveal>
              );
            })}
          </div>

          {/* Interactive Demos Suite */}
          <div className="pt-8">
            <div className="text-center max-w-xl mx-auto mb-6">
              <h3 className="text-xl font-display font-bold text-white flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-cyber-blue" />
                Playable Service Demos (Tier 2 Showcase)
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                Interact with custom checkout baskets, skin tuners, and room scheduler matrixes.
              </p>
            </div>
            <InteractiveDemos />
          </div>

          {/* Enterprise Sales-Optimization Tabs (Tier 3 Showcase) */}
          <div className="pt-20">
            <div className="text-center max-w-xl mx-auto mb-8">
              <h3 className="text-xl font-display font-bold text-white flex items-center justify-center gap-2">
                <Terminal className="w-5 h-5 text-cyber-pink" />
                Enterprise Architectural blueprints (Tier 3 Showcase)
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                Explore the automated mechanics of Home, Shop, Contact, Maps, and FAQ pipelines.
              </p>
            </div>
            <EnterpriseTerminal />
          </div>

          {/* Live AI Voice Agent Preview */}
          <div className="pt-24 max-w-4xl mx-auto">
            <ScrollReveal delay={100} duration={900}>
              <LiveVoiceAgent />
            </ScrollReveal>
          </div>

        </div>
      </section>

      {/* --- PORTFOLIO & USE-CASES SLIDER --- */}
      <section id="portfolio" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <span className="text-xs font-mono text-cyber-blue uppercase tracking-widest block">
              OUR HISTORIC MASTERPIECES
            </span>
            <h2 className="text-3xl font-display font-bold text-white mt-2">
              Explore Our Industry Use-Cases
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-gray-400 max-w-md">
            Click on our specialized templates below to inspect the detailed server latency records, load timelines, and conversion metrics we deploy for high-end brands.
          </p>
        </div>

        {/* Portfolio Tabs selector */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PORTFOLIO_ITEMS.map((item, idx) => {
            const isSelected = selectedPortfolioId === item.id;
            return (
              <ScrollReveal
                key={item.id}
                delay={idx * 100}
                variant="scale"
                className="h-full"
              >
                <button
                  onMouseEnter={playHoverSound}
                  onClick={() => {
                    playClickSound();
                    setSelectedPortfolioId(item.id);
                  }}
                  className={`p-6 rounded-2xl text-left border w-full h-full transition-all cursor-pointer ${
                    isSelected 
                      ? "bg-dark-surface border-cyber-blue shadow-lg shadow-cyber-blue/10 scale-[1.02]" 
                      : "bg-white/[0.01] border-white/5 text-gray-400 hover:border-white/10 hover:bg-white/[0.02]"
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-4xl select-none">{item.image}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                      isSelected 
                        ? "bg-cyber-blue/10 border-cyber-blue text-cyber-blue" 
                        : "bg-white/5 border-white/10 text-gray-400"
                    }`}>
                      {item.badge}
                    </span>
                  </div>

                  <span className="text-[10px] font-mono text-cyber-blue uppercase tracking-wider block mb-1">
                    {item.industry}
                  </span>
                  <h4 className="text-lg font-display font-bold text-white mb-2">
                    {item.title}
                  </h4>
                  <p className="text-xs text-gray-400 leading-relaxed mb-4">
                    {item.description}
                  </p>

                  {/* Spec metrics list */}
                  <div className="pt-4 border-t border-white/5 grid grid-cols-2 gap-3">
                    {item.specs.map((spec, sidx) => (
                      <div key={sidx}>
                        <span className="text-[9px] font-mono text-gray-500 block uppercase">{spec.label}</span>
                        <span className="text-xs font-mono font-bold text-white mt-0.5 block">{spec.value}</span>
                      </div>
                    ))}
                  </div>
                </button>
              </ScrollReveal>
            );
          })}
        </div>

        {/* Interactive Floating Detail Panel relative to active item */}
        <div className="mt-8 p-6 rounded-2xl glass-panel border border-white/10 bg-radial-gradient-glow-1 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyber-blue/10 border border-cyber-blue/30 flex items-center justify-center text-cyber-blue text-xl">
              ⚡
            </div>
            <div>
              <h5 className="font-display font-bold text-sm text-white">Want a tailor-made build of this layout?</h5>
              <p className="text-xs text-gray-400 mt-0.5">Select the matching tier inside the AI Consultation Synthesizer below to generate your direct pipeline blueprint.</p>
            </div>
          </div>
          <a
            href="#contact"
            className="px-5 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-xs font-mono text-white transition-all flex items-center gap-2"
          >
            Launch System Configurator <ArrowUpRight className="w-4 h-4 text-cyber-blue" />
          </a>
        </div>

      </section>

      {/* --- CONTACT & AI BLUEPRINT SYNTHESIZER --- */}
      <section id="contact" className="py-24 bg-black/45 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-mono text-cyber-pink uppercase tracking-widest px-3 py-1 bg-cyber-pink/5 border border-cyber-pink/20 rounded-full">
              SECURE BLUEPRINT GENERATION
            </span>
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mt-4 mb-4">
              AI Project Configurator & Consultation Hub
            </h2>
            <p className="text-sm text-gray-400">
              Submit your project ideas below. You can trigger our **AI Project Architect** (backed by Gemini 3.5) to instantly compile a custom interactive architectural blueprint!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* LEFT SIDE: AI Consultation Form (Glassmorphism) */}
            <div className="lg:col-span-7 glass-panel rounded-2xl p-6 md:p-8 border border-white/10 relative">
              <h3 className="text-xl font-display font-bold text-white mb-6 flex items-center gap-2">
                <Terminal className="w-5 h-5 text-cyber-blue" />
                Initialize Project Influx
              </h3>

              {formSuccess ? (
                <div className="p-8 text-center bg-green-500/10 border border-green-500/30 rounded-xl space-y-4">
                  <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto animate-bounce" />
                  <h4 className="text-lg font-display font-bold text-white">Project Specs Registered!</h4>
                  <p className="text-xs text-gray-300 leading-relaxed max-w-md mx-auto">
                    Excellent choice. Your custom inquiry signal has bypassed active filter routing and landed in our secure Co-founder terminal workspace. We will connect shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleLeadFormSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Name input */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-2 uppercase">Full Name</label>
                      <input
                        type="text"
                        required
                        value={clientName}
                        onChange={(e) => setClientName(e.target.value)}
                        placeholder="e.g. John Doe"
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyber-blue transition-all font-mono"
                      />
                    </div>

                    {/* Email input */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-2 uppercase">Secure Email</label>
                      <input
                        type="email"
                        required
                        value={clientEmail}
                        onChange={(e) => setClientEmail(e.target.value)}
                        placeholder="john@futureweb.org"
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyber-blue transition-all font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Tier choice */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-2 uppercase">Service Track Tier</label>
                      <select
                        value={selectedTier}
                        onChange={(e) => setSelectedTier(e.target.value)}
                        className="w-full bg-[#0d0d14] border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyber-blue transition-all font-mono"
                      >
                        <option>AI & Automation Agents</option>
                        <option>3D Simple Websites</option>
                        <option>Enterprise Full-Stack + App</option>
                      </select>
                    </div>

                    {/* Budget slider/select */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-2 uppercase">Investment Target</label>
                      <select
                        value={budgetRange}
                        onChange={(e) => setBudgetRange(e.target.value)}
                        className="w-full bg-[#0d0d14] border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyber-blue transition-all font-mono"
                      >
                        <option>$5,000 - $10,000</option>
                        <option>$10,000 - $25,000</option>
                        <option>$25,000 - $50,000</option>
                        <option>$50,000+</option>
                      </select>
                    </div>
                  </div>

                  {/* Project description */}
                  <div>
                    <label className="block text-xs font-mono text-gray-400 mb-2 uppercase">
                      Describe your Project requirements
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={projectIdea}
                      onChange={(e) => setProjectIdea(e.target.value)}
                      placeholder="e.g. A fast food digital delivery app with 3D product renders and automated n8n notifications routed to Slack..."
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyber-blue transition-all font-mono leading-relaxed"
                    />
                  </div>

                  {/* AI Blueprint action block */}
                  <div className="p-4 bg-white/[0.01] border border-white/5 rounded-xl space-y-3 relative">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-mono text-cyber-pink font-bold">
                        <Cpu className="w-4 h-4 text-cyber-pink animate-pulse" />
                        AI Blueprint Co-Pilot
                      </div>
                      <span className="text-[9px] font-mono text-gray-500">POWERED BY GEMINI 3.5</span>
                    </div>
                    <p className="text-[11px] text-gray-400 leading-relaxed">
                      Analyze your input project descriptions and build custom, tailored systems blueprints instantly before finalizing.
                    </p>
                    <button
                      type="button"
                      onClick={handleAiBlueprintSynthesis}
                      disabled={aiAnalyzing}
                      className="w-full py-2 bg-gradient-to-r from-cyber-blue/10 to-cyber-purple/10 border border-cyber-blue/30 text-cyber-blue font-mono text-xs font-bold uppercase rounded-lg hover:bg-cyber-blue hover:text-black transition-all flex items-center justify-center gap-2"
                    >
                      {aiAnalyzing ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Synthesizing Architectural Blueprint...
                        </>
                      ) : (
                        "Synthesize Project Architecture Blueprint"
                      )}
                    </button>
                  </div>

                  {/* AI Analysis response terminal */}
                  {aiAnalysisResult && (
                    <div className="p-5 bg-dark-surface border border-cyber-blue/30 rounded-xl font-mono text-xs text-gray-300 leading-relaxed whitespace-pre-wrap max-h-[300px] overflow-y-auto">
                      <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-3 text-[10px] text-cyber-blue">
                        <span>SYSTEM REPORT DISPATCH // SUCCESS</span>
                        <span>CORE STATUS: LIVE</span>
                      </div>
                      {aiAnalysisResult}
                    </div>
                  )}

                  {/* Submit Final Consultation request */}
                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-cyber-blue via-cyber-purple to-cyber-pink text-black font-display font-bold text-xs uppercase tracking-widest rounded-lg transition-all shadow-lg shadow-cyber-blue/25"
                  >
                    Submit Consultation Specifications
                  </button>
                </form>
              )}
            </div>

            {/* RIGHT SIDE: Subscriptions, Map, FAQ */}
            <div className="lg:col-span-5 space-y-8">
              
              {/* STYLISH LOCATION MAP PLACEHOLDER */}
              <div className="glass-panel border border-white/10 rounded-2xl p-6 relative overflow-hidden bg-radial-gradient-glow-2">
                <span className="text-[10px] font-mono text-cyber-purple block uppercase mb-1">
                  Agency Coordinates
                </span>
                <h4 className="text-base font-display font-bold text-white mb-3">
                  Aetheric Headquarters
                </h4>

                {/* SVG High Tech Grid Coordinate Map */}
                <div className="w-full h-40 bg-black/60 border border-white/5 rounded-lg relative overflow-hidden flex items-center justify-center">
                  <div className="absolute inset-0 cyber-grid-dense opacity-20" />
                  
                  {/* Glowing Radar Concentric Rings */}
                  <div className="absolute w-20 h-20 rounded-full border border-cyber-blue/20 animate-ping" />
                  <div className="absolute w-12 h-12 rounded-full border border-cyber-purple/30 animate-pulse" />
                  
                  {/* HQ Node Pin */}
                  <div className="relative z-10 flex flex-col items-center">
                    <MapPin className="w-6 h-6 text-cyber-blue filter drop-shadow-[0_0_8px_#00f0ff] animate-bounce" />
                    <span className="text-[9px] font-mono text-white bg-black/80 px-1.5 py-0.5 rounded border border-white/10 mt-1">
                      SF Node Matrix
                    </span>
                  </div>

                  <div className="absolute bottom-2 left-3 text-[9px] font-mono text-gray-500">
                    LAT: 37.7749° N // LON: 122.4194° W
                  </div>
                </div>
              </div>

              {/* NEWSLETTER SUBSCRIPTION */}
              <div className="glass-panel border border-white/10 rounded-2xl p-6 relative">
                <h4 className="text-base font-display font-bold text-white mb-1.5 flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-cyber-blue" />
                  Newsletter: Stay Ahead of Tech
                </h4>
                <p className="text-xs text-gray-400 mb-4 leading-relaxed">
                  Join 14,000+ engineers receiving our weekly breakdowns of modern WebGL models and voice agent automations.
                </p>

                {emailSubbed ? (
                  <div className="p-3 text-center bg-cyber-blue/10 border border-cyber-blue/30 text-cyber-blue font-mono text-xs rounded-lg animate-pulse">
                    Transmission complete. Verify inbox shortly.
                  </div>
                ) : (
                  <form onSubmit={handleSubscribe} className="flex gap-2">
                    <input
                      type="email"
                      required
                      value={subbedEmail}
                      onChange={(e) => setSubbedEmail(e.target.value)}
                      placeholder="your.email@tech.com"
                      className="flex-1 bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyber-blue transition-all font-mono"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-cyber-blue hover:bg-cyber-blue/80 text-black font-mono text-xs font-bold rounded-lg transition-all"
                    >
                      Subscribe
                    </button>
                  </form>
                )}
              </div>

              {/* DYNAMIC FAQ ACCORDION */}
              <div className="glass-panel border border-white/10 rounded-2xl p-6 relative">
                <h4 className="text-base font-display font-bold text-white mb-4 flex items-center gap-2">
                  <HelpCircle className="w-4.5 h-4.5 text-cyber-pink" />
                  Dynamic Client FAQ
                </h4>

                <div className="space-y-3">
                  {FAQ_ITEMS.map((faq) => {
                    const isOpen = activeFAQ === faq.id;
                    return (
                      <div
                        key={faq.id}
                        className="border-b border-white/5 pb-3 last:border-0 last:pb-0"
                      >
                        <button
                          onClick={() => setActiveFAQ(isOpen ? null : faq.id)}
                          className="w-full flex justify-between items-center text-left text-xs font-display font-semibold text-white hover:text-cyber-blue transition-colors"
                        >
                          <span>{faq.question}</span>
                          <span className="text-gray-500 text-xs ml-2 font-mono">
                            {isOpen ? "[-]" : "[+]"}
                          </span>
                        </button>
                        {isOpen && (
                          <p className="text-xs text-gray-400 leading-relaxed font-mono mt-2 animate-fade-in pl-1">
                            {faq.answer}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* --- FOOTER --- */}
      <footer className="bg-black py-12 border-t border-white/5 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center text-center md:text-left">
          
          <div className="md:col-span-4 space-y-3">
            <span className="font-display font-extrabold text-lg tracking-wider text-white">
              AETHERIC<span className="text-cyber-blue">STUDIOS</span>
            </span>
            <p className="text-xs text-gray-500 leading-relaxed">
              Synthesizing premium digital products with modular 3D interactions and 24/7 autonomous support engines. All rights reserved &copy; 2026.
            </p>
          </div>

          {/* Quick links */}
          <div className="md:col-span-4 flex flex-wrap justify-center gap-6 text-xs font-mono text-gray-400">
            <a href="#home" className="hover:text-cyber-blue transition-colors">Home</a>
            <a href="#services" className="hover:text-cyber-blue transition-colors">Services</a>
            <a href="#portfolio" className="hover:text-cyber-blue transition-colors">Portfolio</a>
            <a href="#contact" className="hover:text-cyber-blue transition-colors">Get Blueprint</a>
          </div>

          {/* Operational specs right */}
          <div className="md:col-span-4 text-center md:text-right space-y-1 text-[10px] font-mono text-gray-500">
            <div>NODE LOCATION: LAT 37.77° N, LON 122.41° W</div>
            <div>STATUS: <span className="text-green-400 font-bold">ALL SYSTEMS LIVE [200 OK]</span></div>
            <div>CRAFTED BY THE FOUNDING DUO IN CO-PRODUCTION</div>
          </div>

        </div>
      </footer>

      {/* Persistent floating 3D AI assistant widget */}
      <AIChatWidget />

    </div>
  );
}
