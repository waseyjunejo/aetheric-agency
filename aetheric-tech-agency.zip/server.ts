import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

// Load environment variables
dotenv.config();

interface LeadQuery {
  id: string;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  selectedTier: string;
  projectIdea: string;
  budgetRange: string;
  createdAt: string;
  aiFeedback?: string;
}

// In-memory array acting as our leads database for active sessions
const leadsDatabase: LeadQuery[] = [
  {
    id: "lead-default-1",
    clientName: "Valerius Sterling",
    clientEmail: "valerius@luxorhotel.world",
    clientPhone: "0333-1234567",
    selectedTier: "3D Simple Websites",
    projectIdea: "A luxury 3D resort reservation platform with real-time immersive suite inspection.",
    budgetRange: "$10,000 - $25,000",
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    aiFeedback: "This high-end hotel project will benefit immensely from a WebGL-based luxury suites preview. We suggest an integrated booking calendar paired with our custom room booking automation agent."
  },
  {
    id: "lead-default-2",
    clientName: "Dr. Elena Vance",
    clientEmail: "vance@neurotech.labs",
    clientPhone: "0300-9876543",
    selectedTier: "AI & Automation Agents",
    projectIdea: "Autonomous customer triage system connecting Retell AI to a local clinical schedule.",
    budgetRange: "$25,000+",
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    aiFeedback: "An excellent use-case for automated voice triage. Implementing a Twilio-backed voice agent synchronized via n8n workflows will optimize client reception and eliminate scheduling conflicts."
  }
];

// Initialize Gemini SDK lazily to avoid crashing if the API key is not present on startup
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return aiClient;
}

const DEFAULT_RECIPIENT_EMAIL = "wjunejo@gmail.com";
const DEFAULT_RECIPIENT_WHATSAPP = "0331249213";

// n8n Webhook Dispatch helper with real-time logger
async function dispatchN8NWebhook(payload: any) {
  const webhookUrl = process.env.N8N_WEBHOOK_URL;
  console.log(`[N8N DISPATCHER] Initiating notification broadcast from source: ${payload.source}`);
  console.log(`[N8N DISPATCHER] Dispatching real-time email notification to: ${payload.recipientEmail || DEFAULT_RECIPIENT_EMAIL}`);
  console.log(`[N8N DISPATCHER] Dispatching instant WhatsApp alert to: ${payload.recipientWhatsApp || DEFAULT_RECIPIENT_WHATSAPP}`);
  
  if (webhookUrl && webhookUrl !== "MY_N8N_WEBHOOK_URL" && webhookUrl !== "") {
    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      console.log(`[N8N DISPATCHER] n8n status code: ${response.status}`);
      return { success: true, status: response.status };
    } catch (err) {
      console.error("[N8N DISPATCHER] Failed to broadcast to n8n webhook:", err);
      return { success: false, error: err };
    }
  } else {
    console.log(`[N8N DISPATCHER] N8N_WEBHOOK_URL is not set. Broadcasting simulated alerts:`);
    console.log(` >> [MOCK EMAIL SENT] To: ${payload.recipientEmail || DEFAULT_RECIPIENT_EMAIL} | Subject: New Lead from ${payload.clientName}`);
    console.log(` >> [MOCK WHATSAPP SENT] To: ${payload.recipientWhatsApp || DEFAULT_RECIPIENT_WHATSAPP} | Message: Alert! New lead ${payload.clientName} registered. Phone: ${payload.clientPhone || "None"}`);
    return { success: true, simulated: true };
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parser middlewares
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // --- API ROUTES ---

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Project Lead Submissions (Consultation Hub)
  app.post("/api/consult/submit", async (req, res) => {
    try {
      const { clientName, clientEmail, clientPhone, selectedTier, projectIdea, budgetRange, aiFeedback } = req.body;
      
      if (!clientName || !clientEmail || !selectedTier || !projectIdea) {
        return res.status(400).json({ error: "Missing required details. Please check form inputs." });
      }

      const newLead: LeadQuery = {
        id: "lead-" + Date.now() + "-" + Math.random().toString(36).substr(2, 5),
        clientName,
        clientEmail,
        clientPhone: clientPhone || undefined,
        selectedTier,
        projectIdea,
        budgetRange: budgetRange || "TBD",
        createdAt: new Date().toISOString(),
        aiFeedback: aiFeedback || undefined
      };

      leadsDatabase.unshift(newLead);

      // Trigger Webhook & real-time notification
      await dispatchN8NWebhook({
        source: "Consultation Hub",
        clientName,
        clientEmail,
        clientPhone: clientPhone || "",
        selectedTier,
        projectIdea,
        budgetRange: budgetRange || "TBD",
        aiFeedback: aiFeedback || undefined,
        recipientEmail: DEFAULT_RECIPIENT_EMAIL,
        recipientWhatsApp: DEFAULT_RECIPIENT_WHATSAPP
      });

      return res.status(201).json({ success: true, lead: newLead });
    } catch (err: any) {
      console.error("Error submitting project consult:", err);
      return res.status(500).json({ error: "Failed to process project inquiry. Server issue." });
    }
  });

  // Fluid Digital Menu Order Submissions
  app.post("/api/restaurant/submit", async (req, res) => {
    try {
      const { clientName, clientEmail, clientPhone, orderItems, totalAmount } = req.body;

      if (!clientName || !clientEmail || !clientPhone || !orderItems || orderItems.length === 0) {
        return res.status(400).json({ error: "Missing checkout parameters. Check your Cart." });
      }

      const itemsDesc = orderItems.map((item: any) => `${item.qty}x ${item.name} ($${item.price} each)`).join(", ");
      const projectIdea = `Fluid Digital Menu checkout order containing: ${itemsDesc}`;

      const newLead: LeadQuery = {
        id: "menu-order-" + Date.now() + "-" + Math.random().toString(36).substr(2, 5),
        clientName,
        clientEmail,
        clientPhone,
        selectedTier: "3D Simple Websites",
        projectIdea,
        budgetRange: `$${totalAmount.toFixed(2)}`,
        createdAt: new Date().toISOString(),
        aiFeedback: "This user completed a real checkout simulation inside the Tier 2 Fluid Digital Menu interface."
      };

      leadsDatabase.unshift(newLead);

      // Trigger Webhook & real-time notification
      await dispatchN8NWebhook({
        source: "Fluid Digital Menu",
        clientName,
        clientEmail,
        clientPhone,
        selectedTier: "3D Simple Websites",
        projectIdea,
        budgetRange: `$${totalAmount.toFixed(2)}`,
        orderItems,
        totalAmount,
        recipientEmail: DEFAULT_RECIPIENT_EMAIL,
        recipientWhatsApp: DEFAULT_RECIPIENT_WHATSAPP
      });

      return res.status(201).json({ success: true, lead: newLead });
    } catch (err: any) {
      console.error("Error submitting restaurant order:", err);
      return res.status(500).json({ error: "Failed to process digital menu checkout." });
    }
  });

  // AI Chat & Dynamic Multilingual Voice Agent Endpoint using Gemini
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { messages } = req.body;

      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "No conversation history provided." });
      }

      const client = getAiClient();
      
      const systemInstruction = `
You are the expert, ultra-premium sales executive AI Agent of "Aetheric Tech Agency" (also known as Aetheric Studios), an elite 3D Web & AI/Automation agency.
Your mission is to welcome visitors, answer questions professionally and futuristically, and seamlessly generate client leads or book project orders.

OUR AGENCY PROFILE & SERVICES (3-Tier Showroom):
1. Tier 1: AI & Automation Agents
   - Description: Fully autonomous workflow automation, custom AI agent nodes, Retell AI voice synthesis, and secure n8n data processing pipelines.
   - Ideal for: Dental/clinical voice receptionists, active ticket triages, automated lead processors, schedule routers.
   - Starting Price / Scope: Custom quotes.

2. Tier 2: 3D Simple Websites
   - Description: Stunning, immersive WebGL websites with interactive canvas layouts, Three.js visuals, glassmorphism UI/UX, and rapid checkout menus.
   - Features: Fluid Frame Rate (up to 120fps), custom 3D particle cores, responsive layouts.
   - Pricing: $10,000 - $25,000.

3. Tier 3: Enterprise Full-Stack Apps
   - Description: High-throughput custom software solutions, advanced database synchronization (Cloud Firestore/Cloud SQL), robust Express backend routing, CRM integrations, and full mobile + web application suites.
   - Pricing: $25,000+.

OUR CO-FOUNDERS / TEAM COORDS:
- Location: San Francisco (SF) Node Matrix (LAT: 37.7749° N, LON: 122.4194° W).
- Active Contacts: Email wjunejo@gmail.com, WhatsApp 0331249213.

CONVERSATIONAL RULES:
1. Dynamic Language Prediction: Detect the user's language (English, Sindhi, French, Spanish, German, etc.) from their messages and adapt immediately, responding in that exact language for the entire conversation. Keep your tone elite, professional, and slightly futuristic.
2. Initial Greeting: If the user says hello or just starts, greet them warmly: "Hello, welcome to our website!" (or the translated equivalent).
3. Contextual Expertise: Act as the ultimate Sales Executive. Answer questions accurately based on our 3-Tier Showroom services. Avoid making up services we don't offer.
4. Conversational Lead Generation & Order Booking:
   - Your primary goal is to collect their:
     a) Full Name
     b) Email Address
     c) Phone/WhatsApp Number
   - Be conversational. Do not dump a boring form of questions immediately. Ask nicely as the conversation progresses (e.g. "To compile a personalized blueprint quote for your 3D web platform, may I secure your Name and Email?").
   - Once they provide these details, confirm that our systems have registered them: "Excellent. I've compiled your specs. I am now initiating our high-speed notification protocols. Our founders will reach out to finalise your custom cybernetic architecture!"
   - ALWAYS include the phrase "[LEAD_DATA_DETECTED: Name: <name>, Email: <email>, Phone: <phone>]" at the very end of your response once you have successfully collected all three of these data points (Name, Email, and Phone). This allows the frontend to trigger a beautiful live order confirmation card!
      `;

      if (!client) {
        // High quality fallback with language adaptation simulation
        const lastMessage = messages[messages.length - 1]?.parts?.[0]?.text || "";
        let fallbackReply = "Hello! I am your Aetheric Sales Executive. Since the neural synthesizer core is currently offline, I can guide you directly. We offer 3-Tier solutions: AI Agents, 3D Websites, and Enterprise Apps. Please leave your Name, Email, and Phone number here, and we will get back to you immediately at wjunejo@gmail.com!";
        
        if (lastMessage.toLowerCase().includes("sindhi") || lastMessage.includes("ڀلي ڪري آيا")) {
          fallbackReply = "هيلو! آئون اٿيرڪ سيلز ايگزيڪيوٽو آهيان. اسان ٽن درجن واريون خدمتون پيش ڪريون ٿا: AI ايجنٽ، 3D ويب سائيٽون، ۽ فل اسٽيڪ ائپس. مهرباني ڪري پنهنجو نالو، اي ميل ۽ فون نمبر هتي لکو ته جيئن اسان رابطو ڪري سگهون!";
        } else if (lastMessage.toLowerCase().includes("french") || lastMessage.includes("bonjour")) {
          fallbackReply = "Bonjour! Je suis votre conseiller commercial Aetheric. Nous proposons trois services: Agents IA, Sites Web 3D et Applications Enterprise. Veuillez nous laisser votre nom, e-mail et numéro de téléphone afin que nous puissions vous contacter !";
        }
        
        return res.json({ text: fallbackReply, mock: true });
      }

      // Prepare contents for Gemini API call
      // map the input array of messages to the required format
      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: messages,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      return res.json({ text: response.text, mock: false });
    } catch (error: any) {
      console.error("AI chat error:", error);
      return res.status(500).json({ error: "AI Chat terminal offline. Please try again soon." });
    }
  });

  // AI Widget Lead / Booking Order Submission
  app.post("/api/ai/book-order", async (req, res) => {
    try {
      const { clientName, clientEmail, clientPhone, projectIdea, selectedTier } = req.body;

      if (!clientName || !clientEmail || !clientPhone) {
        return res.status(400).json({ error: "Missing required contact parameters." });
      }

      const tier = selectedTier || "AI & Automation Agents";
      const idea = projectIdea || "Custom sales lead generated through Floating 3D AI Chat/Voice widget.";

      const newLead: LeadQuery = {
        id: "ai-widget-lead-" + Date.now() + "-" + Math.random().toString(36).substr(2, 5),
        clientName,
        clientEmail,
        clientPhone,
        selectedTier: tier,
        projectIdea: idea,
        budgetRange: "TBD (AI Widget Capture)",
        createdAt: new Date().toISOString(),
        aiFeedback: "Captured seamlessly through the floating interactive Sales Executive AI Widget."
      };

      leadsDatabase.unshift(newLead);

      // Trigger Webhook & real-time notification
      await dispatchN8NWebhook({
        source: "Floating AI Widget",
        clientName,
        clientEmail,
        clientPhone,
        selectedTier: tier,
        projectIdea: idea,
        budgetRange: "TBD",
        recipientEmail: DEFAULT_RECIPIENT_EMAIL,
        recipientWhatsApp: DEFAULT_RECIPIENT_WHATSAPP
      });

      return res.status(201).json({ success: true, lead: newLead });
    } catch (err: any) {
      console.error("Error booking order via widget:", err);
      return res.status(500).json({ error: "Failed to register AI widget order." });
    }
  });

  // Retrieve Lead List for Founders Control Panel
  app.get("/api/consult/list", (req, res) => {
    res.json({ success: true, leads: leadsDatabase });
  });

  // AI Project Advisor Endpoint using Gemini 3.5 Flash
  app.post("/api/ai/analyze-project", async (req, res) => {
    try {
      const { projectIdea, selectedTier } = req.body;

      if (!projectIdea) {
        return res.status(400).json({ error: "Please enter a brief description of your project or agency needs!" });
      }

      const client = getAiClient();
      if (!client) {
        // Fallback response with an ultra-realistic, premium mock architectural report if no Gemini API key
        const premiumMockResponse = `
### ⚡ NEURAL DESIGN PROTOCOL ACTIVATED (API Key Fallback)
Here is our recommended cybernetic architecture for your project:

1. **Strategic Concept & UX Core**:
   - Specialization matching **${selectedTier || "Enterprise Full-Stack"}** tier.
   - We suggest a sleek, fluid glassmorphic single-page architecture loaded with 3D interactions utilizing Framer Motion.

2. **Autonomous Automation & Middleware**:
   - Integrates secure webhook handlers routed to n8n to connect automated databases or scheduling pipelines.
   - Configures active speech channels (Retell AI) for customer inquiries, synchronized with a real-time lead engine.

3. **Technical Stack Recommendation**:
   - **Frontend**: Vite + React 19 + Tailwind CSS (Cyberpunk Slate Theme).
   - **Interactive Layer**: Three.js / Canvas context for beautiful custom visualizers.
   - **Backend Core**: Lightweight NodeJS / Express microservice cluster.
   - **Durable Storage**: Cloud Firestore for active user profiles and secure logs.

*Submit your consultation request using the form below, and our team will synthesize this blueprint into reality!*
        `;
        return res.json({ response: premiumMockResponse.trim(), mock: true });
      }

      const prompt = `
You are the lead Tech Architect and Head of Design at Aetheric AI & 3D Web Agency.
Analyze the following project description submitted by a prospective client.
Provide an ultra-premium, modern, and exciting technical architecture report in clean markdown.

Client Selected Tier: ${selectedTier || "Unspecified"}
Client Project Description: "${projectIdea}"

Format your response in exactly 4 sections with futuristic headers:
### ⚡ NEURAL DESIGN SYSTEM ARCHITECTURE
(Describe a breathtaking visual design layout, animations, and typography suited for their project - mention details like glassmorphism, glowing micro-interactions, canvas structures, or responsive fluid grids)

### 🤖 CO-PILOT AUTOMATION ENGINE
(Detail the specific n8n, LLM, or voice agent workflows, triggers, and automated workflows that will supercharge this product)

### 🛠️ FULL-STACK BLUEPRINT & DATA SCHEMA
(Specify the ideal tech stack, database schemas, API pathways, and server routing to support their features)

### 📈 SCALE & REVENUE OPTIMIZATION
(Share a custom, highly strategic advice point on how to drive conversions, bookings, or user engagement for this specific model)

Keep the language professional, futuristic, inspiring, and direct. Avoid rambling. Avoid placeholders. Use elegant bullet points and strong markdown styling.
      `;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are the world-class lead technologist and elite UI designer for Aetheric Agency, an ultra-premium 3D & AI software shop. Your blueprints are flawless, hyper-modern, and styled beautifully."
        }
      });

      return res.json({ response: response.text, mock: false });
    } catch (error: any) {
      console.error("Gemini query error:", error);
      return res.status(500).json({ error: "AI Synthesis temporarily offline. Please try submitting again." });
    }
  });

  // --- VITE MIDDLEWARE OR STATIC SERVING ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // Serve HTML entry for SPA routing (Express v4 format is app.get('*', ...))
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[AETHERIC SERVER] Active at http://0.0.0.0:${PORT} under NODE_ENV=${process.env.NODE_ENV || "development"}`);
  });
}

startServer();
